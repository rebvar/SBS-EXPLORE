/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SBSExplore;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import weka.core.Instances;

/**
 *
 * @author sehossei
 */
class myRunner implements Runnable {

    int iters;
    int folds;
    GIS gis;
    Instances trainSetAll;
    Instances testSetAll;
    Instances trainSetckloc;
    Instances testSetckloc;
    Instances trainSetInfoGain;
    Instances testSetInfoGain;
    private String file;
    String[] files;

    public myRunner(int iters, int folds, Instances trainSetAll, Instances testSetAll, Instances trainSetckloc, Instances testSetckloc, Instances trainSetInfoGain, Instances testSetInfoGain, String file, String[] files) {

        this.file = file;
        this.iters = iters;
        this.folds = folds;
        this.trainSetAll = trainSetAll;
        this.testSetAll = testSetAll;
        this.trainSetckloc = trainSetckloc;
        this.testSetckloc = testSetckloc;
        this.trainSetInfoGain = trainSetInfoGain;
        this.testSetInfoGain = testSetInfoGain;
        gis = new GIS();
        gis.file = file;
        this.files = files;
    }

    @Override
    public void run() {
        

        try {
        
            FileWriter fout = new FileWriter("D:/GISOUT/EXPLORE/NEW-GIS-" + String.valueOf(System.currentTimeMillis()) + " -- File=[" + file + "].txt");
            int c = 0;
            
            while (c < iters) {
                
                System.out.println("Start:"+file+": "+String.valueOf(c));
                
                fout.write("#ITERINFO:For File=" + file + "-Iter:" + String.valueOf(c)+"\n");
                               
                gis.GIS(trainSetAll, testSetAll, "Gen-A", fout,0, true);
                gis.GIS(trainSetInfoGain, testSetInfoGain, "Gen-IG", fout,0, true);

                gis.GIS(trainSetAll, testSetAll, "VAT-Gen-A", fout,1,true);
                gis.GIS(trainSetInfoGain, testSetInfoGain, "VAT-Gen-IG", fout,1,true);

                gis.GIS(trainSetAll, testSetAll, "VRnd-Gen-A", fout,2,true);
                gis.GIS(trainSetInfoGain, testSetInfoGain, "VRnd-Gen-IG", fout,2,true);
//                
//
//
//                
                gis.GIS(trainSetAll, testSetAll, "VAR.Gen-A", fout,0, false);
                gis.GIS(trainSetInfoGain, testSetInfoGain, "VAR.Gen-IG", fout,0, false);
//                
                gis.GIS(trainSetAll, testSetAll, "VAR.VAT-Gen-A", fout,1,false);
                gis.GIS(trainSetInfoGain, testSetInfoGain, "VAR.VAT-Gen-IG", fout,1,false);
//
                gis.GIS(trainSetAll, testSetAll, "VAR.VRnd-Gen-A", fout,2,false);
                gis.GIS(trainSetInfoGain, testSetInfoGain, "VAR.VRnd-Gen-IG", fout,2,false);

                fout.write("----------------------------------------------\n");
                fout.flush();
                System.gc();
                System.out.println("Finished:"+file+": "+String.valueOf(c));
                c++;
            }
            
            fout.write("===================================================================\n");
            fout.close();
            
            System.out.println("File Processing Ended:"+file);
        } catch (Exception e) {
            e.printStackTrace();

        }
        
    }

}

public class BC {

    public static int iters = 20;

    public static void RunTests()
            throws Exception {

        DPLIB.useIterativeInfoGainSubsetting = true;

        int folds = 10;

        
        String Path="D:/GISOUT/EXPLORE";
        java.io.File PathFolder = new File(Path);
        if (!PathFolder.exists())
            PathFolder.mkdirs();
        
        ExecutorService procs = Executors.newFixedThreadPool(2);
 
        String startTST = "";
        String endTST = "";
        String[] files = DPLIB.getFiles(DPLIB.dp);
        for (String file : files) {
            if (endTST.length()>0 && file.compareTo(endTST)>=0)
                break;
            if (file.compareTo(startTST) >= 0) {
                ArrayList<String> train = new ArrayList<String>();
                for (String file2 : files) {
                    if (!file2.substring(0, 3).equals(file.substring(0, 3))) {
                        train.add(file2);
                    }
                }

                //gis.file = file;
                ArrayList<String> test = new ArrayList<String>();
                test.add(file);
                Instances trainSetAll = DPLIB.LoadCSV(train, DPLIB.dp, DPLIB.featuresALL);
                Instances testSetAll = DPLIB.LoadCSV((ArrayList) test, DPLIB.dp, DPLIB.featuresALL);

                Instances trainSetckloc = null;
                Instances testSetckloc = null;

                int indi[] = DPLIB.fSelectInfoGain(trainSetAll);
                int indis2[] = null;
                if (DPLIB.useIterativeInfoGainSubsetting) {
                    indis2 = DPLIB.iterativeInfoGainSubsetting(trainSetAll, indi);
                } else {
                    indis2 = DPLIB.getTopX(indi);
                }

                Instances trainSetInfoGain = DPLIB.fSelectSet(trainSetAll, indis2);
                Instances testSetInfoGain = DPLIB.fSelectSet(testSetAll, indis2);

                procs.submit(new myRunner(iters, folds, trainSetAll, testSetAll, trainSetckloc, testSetckloc, trainSetInfoGain, testSetInfoGain, file, files));
            }
        }

        procs.shutdown();

        try {
            procs.awaitTermination(100, TimeUnit.DAYS);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            
        }
        
    }
}
