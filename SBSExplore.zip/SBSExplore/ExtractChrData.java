/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SBSExplore;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import weka.core.Instances;

/**
 *
 * @author sehossei
 */
public class ExtractChrData {

    public static void Extract(int[] features) throws Exception {

        double recallMin = 0.7;
        double precMin = 0.5;
        int numDistChars = 16;
        int numAttrs = features.length - 1;
        String Path = "D:/He Univ/";
        HashMap<String, Instances> dss = new HashMap<>();

        String[] files = DPLIB.getFiles(DPLIB.dp);
        String[] prfiles = DPLIB.getFiles(Path + "Preds/", ".txt");

        for (int fileIndex = 0; fileIndex < prfiles.length; fileIndex++) {
            String outFileName = Path + "OutChar/" + String.valueOf(fileIndex) + "OutChr-" + prfiles[fileIndex];
            File foutFile = new File(outFileName);
            if (foutFile.exists()) {
                System.out.println("Skipping existing file:" + prfiles[fileIndex]);
                continue;
            }
            FileWriter fout = new FileWriter(outFileName);

            Prepare(fout, numAttrs, numDistChars, "File" + String.valueOf(fileIndex));

            File pathDir = new File(Path + "OutChar/" + String.valueOf(fileIndex) + "/");
            pathDir.mkdir();

            String fNames = prfiles[fileIndex];
            fNames = fNames.substring(fNames.indexOf("(") + 1, fNames.indexOf(")"));
            String[] dsinds = fNames.split(",");
            for (int i = 0; i < dsinds.length; i++) {
                String fName = files[Integer.valueOf(dsinds[i])];
                dss.put(fName, DPLIB.LoadCSV(fName, DPLIB.dp, features));
            }

            HashMap<String, String> dists = new HashMap<>();
            
            BufferedReader br = new BufferedReader(new FileReader(Path + "OutCharIndividualUniversal"));
            String line;

            while ((line = br.readLine()) != null) {

                if (line.indexOf("\n") > 0) {
                    line = line.substring(0, line.indexOf("\n"));
                }
                if (line.length() == 0) {
                    continue;
                }
                String parts[] = line.split(";");

                dists.put(parts[0], parts[1]);
            }
            br.close();

            br = new BufferedReader(new FileReader(Path + "Preds/" + prfiles[fileIndex]));
            line = null;

            int lno = 0;
            
            HashMap<String, FileWriter[]> OutFiles = new HashMap<>();
            
            while ((line = br.readLine()) != null) {
                lno++;
                if (lno % 500 == 0) {
                    System.out.println(lno);
                }
                
                
                String parts[] = line.split(";");
                String test = parts[0];
                if (!OutFiles.containsKey(test))
                {
                    FileWriter[] outfilestest = new FileWriter[]{new FileWriter(Path+"OutChar/"+String.valueOf(fileIndex)+"/"+test+"-traindata.txt")
                                                       ,new FileWriter(Path+"OutChar/"+String.valueOf(fileIndex)+"/"+test+"-testdata.txt")};
                    Prepare(outfilestest[0], numAttrs, numDistChars, test);
                    Prepare(outfilestest[1], numAttrs, numDistChars, test);
                    OutFiles.put(test, outfilestest);                    
                }
                
                String trains = parts[1];
                String[] trainsLst = parts[1].split(",");
                String distCharsTrain;
                String distCharsTest = dists.get(test);
                String[] results = parts[3].substring(parts[3].indexOf("[") + 1, parts[3].indexOf("]")).split(",");
                double[] resultsNum = new double[results.length];
                for (int i = 0; i < results.length; i++) {
                    resultsNum[i] = Double.valueOf(results[i].trim());
                }

                String resTot = "0";
                if (resultsNum[0] > recallMin && resultsNum[1] >= precMin) {
                    resTot = "1";
                }

                if (dists.containsKey(trains)) {
                    distCharsTrain = dists.get(trains);
                } else {
                    String outStr = ExtractDistChars(trainsLst, dss, numAttrs);

                    dists.put(trains, outStr);
                    distCharsTrain = outStr;

                }

                String out = distCharsTrain + "," + distCharsTest + "," + resTot + "\n";
                if (out.contains(",,")) {
                    System.out.println("Error");
                }

                fout.write(out);

            }
            fout.close();
            br.close();
            dists = null;
            System.gc();
        }

    }

    private static String ExtractDistChars(String[] trainsLst, HashMap<String, Instances> dss, int numAttrs) {
        int numInstances = 0;
        String outStr = "";
        for (int i = 0; i < trainsLst.length; i++) {
            numInstances += dss.get(trainsLst[i]).numInstances();
        }
        double[] attrdata = new double[numInstances];
        MathFuncs mf = new MathFuncs();
        for (int j = 0; j < numAttrs; j++) {
            int counter = 0;
            for (int i = 0; i < trainsLst.length; i++) {
                Instances ds = dss.get(trainsLst[i]);

                for (int k = 0; k < ds.numInstances(); k++) {
                    attrdata[counter] = ds.instance(k).value(j);
                    counter++;
                }
            }
            mf.set(attrdata);
            double vals[] = mf.getallDistChars();

            for (int t = 0; t < vals.length; t++) {
                outStr += String.valueOf(vals[t]) + ",";
            }

            if (j == numAttrs - 1) {
                outStr = outStr.substring(0, outStr.length() - 1);
            }
        }
        return outStr;
    }

    private static void Prepare(FileWriter fout, int numAttrs, int numDistChars, String rel) throws Exception {
        fout.write("@RELATION " + rel + "\n\n\n");
        for (int i = 0; i < numAttrs * numDistChars * 2; i++) {
            fout.write("@ATTRIBUTE COL" + String.valueOf(i) + " REAL\n");
        }

        fout.write("@ATTRIBUTE CLASS {0,1}\n\n\n\n@data\n\n");

    }
}
