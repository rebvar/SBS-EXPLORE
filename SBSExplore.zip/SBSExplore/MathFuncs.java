/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SBSExplore;

import java.util.ArrayList;
//import org.apache.commons.math3;


import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author sehossei
 */
public class MathFuncs {
    public double[] numbers;
    
    public MathFuncs()
    {
        
        
    }
    
    
    public void set (double[] nums)
    {
        numbers = nums;
        Arrays.sort(numbers);
    }
    
    public double min()
    {
        double m = numbers[0];
        
        for (int i = 1;i<numbers.length;i++)
        {
            if ( numbers[i]<m)
                m = numbers[i];
        }
        return m;
    }
    
    public double max()
    {
        double m = numbers[0];
        
        for (int i = 1;i<numbers.length;i++)
        {
            if ( numbers[i]>m)
                m = numbers[i];
        }
        return m;
    }
    
    
    public double mean()
    {
        double m = 0;
        for (int i = 0;i<numbers.length;i++)
        {
            
            m+=numbers[i];
        }
        return m/numbers.length;
    }
    
    public double median()
    {
        int idx = (int)numbers.length/2;
        if (numbers.length%2 == 0)
        {
            
            return (numbers[idx-1]+numbers[idx])/2;
        }
        else
        {
            return numbers[idx];
        }
        
    }
    
    
    public double median(double[] numbers)
    {
        if (numbers.length == 0)
            return 0;
        
        int idx = (int)numbers.length/2;
        if (numbers.length%2 == 0)
        {
            
            return (numbers[idx-1]+numbers[idx])/2;
        }
        else
        {
            return numbers[idx];
        }
        
    }
    
    
    public double variance()
    {
        double v = 0;
        double m = mean();
        for (int i = 0;i<numbers.length;i++)            
        {
            v+=(numbers[i]-m)*(numbers[i]-m);
        }
        return v/(numbers.length-1);
    }
    
    
    public double std()
    {
        return Math.sqrt(variance());
    }
    
    public double hmean()
    {
        double hm = 0;
        for (int i = 0;i<numbers.length;i++)
        {
            if (numbers[i]<=Consts.ep)
            {
                return 0;
            }
            hm+=1.0/numbers[i];
        }
        
        return numbers.length/hm;
    }
    
    
    public double[] mode()
    {
        HashMap<Double,Integer> hm=new HashMap<Double,Integer>();
        int max=0;
        double temp=-1000000000;
        for(int i=0;i<numbers.length;i++)
        {
            if(hm.get(numbers[i])!=null)
            {
                int count=hm.get(numbers[i]);
                count=count+1;
                hm.put(numbers[i],count);
                if(count>max)
                {
                    max=count;
                    temp=numbers[i];
                }
            }
            else
            {
                hm.put(numbers[i],1);
            }
        }
        
        return new double[] {temp,max};
    }
    
    public double varRatio(){
        double md[] = mode();
        return 1.0-(double)md[1]/(double)numbers.length;
    }
    
    public double fquartile()
    {
        int count = numbers.length;
        
        
        int half = (int)count/2;
        double[] portion = new double[half];
        
        for (int i = 0;i<half;i++)
            portion[i] = numbers[i];
        return median(portion);
        
        
    }
    
    
    public double lquartile()
    {
        int count = numbers.length;
        
        
        int half = (int)count/2;
        
            
        double[] portion = new double[half];
        
        int start = 0;
        if (count%2==1)
            start = 1;
        
        for (int i = 0;i<half;i++)
            portion[i] = numbers[start+half+i];
        
        return median(portion);         
    }
    
    
    public double iqr()
    {
        return lquartile()-fquartile();
    }
    
    
    public double coefvar ()
    {
        double st = std();
        if (st==0)
            return -1;        
        return mean()/st;
    }

    public double skew()
    {
        double mu = mean();
        double st = std();
        if (st == 0)
            return 0;
        double s = 0;
        for(int i = 0;i< numbers.length;i++)
        {
            double x = numbers[i];        
            s+=(x-mu)*(x-mu)*(x-mu);
        }
        return s/((st*st*st)*numbers.length);
    }
    
    
    public double kurt()
    {
        double mu = mean();
        double st = std();
        if (st == 0)            
            return 0;
        double s = 0;
        for(int i = 0;i< numbers.length;i++)
        {
            double x = numbers[i];        
            s+=(x-mu)*(x-mu)*(x-mu)*(x-mu);
        }
        return s/((st*st*st*st)*numbers.length);
    }
    
    
    public double range()
    {
        return max()-min();
    }

    public double[] getallDistChars()
    {
        double[] distchars = new double[] {min(),max(),median(),mode()[0],mean(),std(),variance(),range(),iqr(),fquartile(),lquartile(), skew(),kurt(), coefvar(),hmean(),varRatio()};
        for (int i = 0;i<distchars.length;i++)
        {
            distchars[i] = Math.floor(distchars[i]*1000.0)/1000.0;
        }
        return distchars;
    }
    
}
