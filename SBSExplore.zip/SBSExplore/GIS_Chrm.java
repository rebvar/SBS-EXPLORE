/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SBSExplore;

/**
 *
 * @author sehossei
 */

import weka.core.Instances;

public class GIS_Chrm  implements IChrm{
    public Instances ds;
    public double[] fitness;
    
    public double[] conf;
    public double[] testConf;
    public double[] testFitness;
    public GIS_Chrm(Instances ds, double[] fitness)
    {
        this.ds=ds;
        this.fitness = fitness;
    
    }    
    
    public GIS_Chrm(Instances ds, double[] fitness, double[] conf, double testConf[], double[] testFitness)
    {
        this.ds=ds;
        this.fitness = fitness;
        this.conf = conf;
        this.testConf = testConf;
        this.testFitness = testFitness;
    }  
    
    
    @Override
    public double getFitness()
    { 
        double fit = getCustom();
        if (Double.isNaN(fit))
            return 0;        
        fit = Math.floor(fit*1000.0)/1000.0;
                
        return fit;
                
    }

    @Override
    public double getCustom() {
        return getGMEAN()*MCC();
    }
    
    
    public double MCC()
    {
        //tp, tn, fp, fn        
        double tp = conf[0], tn = conf[1], fp = conf[2],fn = conf[3];                
        return (tp*tn-fp*fn)/(Math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)));
    }
    
    
    public double getBalance()
    {
        double tp = conf[0], tn = conf[1], fp = conf[2],fn = conf[3];        
        double pf = (fp)/(fp+tn);
        return 1-(Math.sqrt(pf*pf+(1-fitness[0])*(1-fitness[0]))/Math.sqrt(2));        
    }
    
    
    @Override
    public double getGMEAN() {
        return Math.sqrt(fitness[1]*fitness[0]);
    }
    
    
    @Override
    public double getF() {
        return fitness[3];
    }
    
    
    public double getF_0_5() {
        return 1.25*fitness[0]*fitness[1]/(fitness[0]+0.25*fitness[1]);
    }
}