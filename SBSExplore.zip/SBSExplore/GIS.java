/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SBSExplore;


import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import weka.classifiers.Evaluation;
import weka.core.Instances;
import weka.classifiers.evaluation.Prediction;

import weka.classifiers.trees.J48;


/**
 *
 * @author sehossei
 */
public class GIS {

    public int popSize = 30;
    public double chrmSize = 0.02D;

    public int numGens = 30;

    public int numParts = 1;

    public int sizeTopP = 0;

    public int count = 1;

    public FileWriter fout;

    public String file;
    
    

    public void GIS(Instances trainSeti, Instances testSeti, String name, FileWriter fout, int vSetType, boolean fixedTrainSize) throws Exception {
        long starttime, endtime;
        starttime = System.currentTimeMillis();

        ArrayList<ArrayList<Prediction>> preds = new ArrayList();
        ArrayList<IChrm> pop = new ArrayList();        

        Instances trainSet = new Instances(trainSeti);
        Instances testSet = new Instances(testSeti);
        pop.clear();

        int tstSize = testSet.numInstances();
        int partSize = (int) Math.floor(tstSize / numParts);
        preds.clear();
        double[] vals = null;
        ArrayList<ArrayList<Double>> diffs = new ArrayList<>();
        
        testSet.randomize(DPLIB.rnd);
        
        J48 temp = new J48();
        
                                       
        fout.write("#GIS-OPTIONS;;For="+name+"@"+":iters=" + String.valueOf(BC.iters) + "-POPSIZE=" + String.valueOf(popSize) + "-NumParts=" + String.valueOf(numParts) + "-NumGens=" + String.valueOf(numGens) + "-CHRMSize=" + String.valueOf(chrmSize) + "-sizeTop=" + String.valueOf(sizeTopP) + "-Learner=" + temp.getClass().getSimpleName()+"\n");
        if (file.toLowerCase().endsWith(".arff"))                
            file = file.substring(0, file.length()-5);
        
        String retVal="";
        for (int p = 0; p < numParts; p++) {
            ArrayList<Double> diffp = new ArrayList<>();
        
            pop.clear();
            int start = p * partSize;
            int end = (p + 1) * partSize;
            if (end > tstSize) {
                end = tstSize;
            }
            if (p == numParts - 1) {
                end = tstSize;
            }

            Instances testPart = new Instances(testSet, 0);
            for (int t = start; t < end; t++) {
                testPart.add(testSet.instance(t));
            }            
                        
            HashSet<Integer> uinds = new HashSet<Integer>();
            
            Instances vSet = null;
            
            if (vSetType==1)
            {
                vSet = trainSeti;
                retVal = DPLIB.getStats(vSet, true, true, true);
                fout.write("#VSETINFO;;prt="+String.valueOf(p)+";;For="+name+"@"+":"+retVal+"\n");
                fout.flush();
                retVal = null;
            }
            else if (vSetType==0)
            {
                vSet = DPLIB.NNFilterMulti(trainSet, testPart, 1);
                retVal = DPLIB.getStats(vSet, true, true, true);
                fout.write("#VSETINFO;;prt="+String.valueOf(p)+";;For="+name+"@"+":"+retVal+"\n");
                fout.flush();
                retVal = null;
            }
            else if (vSetType == 2)
            {
                
                int size = testPart.numInstances(); //DPLIB.rnd.nextInt((int) (trainSet.numInstances() * chrmSize))+(int)(vSet.size()/3);
                vSet = new Instances(trainSet, 0);
                int j = 0;
                while (j < size) {
                    int index = DPLIB.rnd.nextInt(trainSet.numInstances());
                    
                    if (!uinds.contains(index)) {
                        uinds.add(index);
                    }
                    else
                    {
                        continue;
                    }
                    
                    vSet.add(trainSet.instance(index));                    
                    j++;
                }
                
                
                retVal = DPLIB.getStats(vSet, true, true, true);
                fout.write("#VSETINFO;;prt="+String.valueOf(p)+";;For="+name+"@"+":"+retVal+"\n");
                fout.flush();
                retVal = null;
                
            }                      
            
            else if (vSetType == 3)
            {
                
                //Upper Bound. Should not be used.
                vSet = testSeti;
                retVal = DPLIB.getStats(vSet, true, true, true);
                fout.write("#VSETINFO;;prt="+String.valueOf(p)+";;For="+name+"@"+":"+retVal+"\n");
                fout.flush();
                retVal = null;
            }
            
            uinds.clear();
            for (int i = 0; i < popSize; i++) {                
                int size;
                if (fixedTrainSize)
                    size = (int) (trainSet.numInstances() * chrmSize); //DPLIB.rnd.nextInt((int) (trainSet.numInstances() * chrmSize))+(int)(vSet.size()/3);
                else
                    size = DPLIB.rnd.nextInt((int) (trainSet.numInstances() * chrmSize))+100;
                
                Instances trSet = new Instances(trainSet, 0);
                int j = 0;
                while (j < size) {
                    int index = DPLIB.rnd.nextInt(trainSet.numInstances());
                    trSet.add(trainSet.instance(index));
                    
                    if (!uinds.contains(index)) {
                        uinds.add(index);
                    }

                    j++;
                }
                
                
                J48 l = new J48();

                l.buildClassifier(trSet);

                Evaluation evaluation = new Evaluation(trSet);
                if (vSet != null)
                {
                    evaluation.evaluateModel(l, vSet, new Object[0]);
                }
                else
                {
                    evaluation.evaluateModel(l, trSet, new Object[0]);
                }
                
                ArrayList<Prediction> vec = evaluation.predictions();
                vals = DPLIB.getResults(vec);
                double vals2[] = DPLIB.getMeasures(vals);
                evaluation = new Evaluation(trSet);
                evaluation.evaluateModel(l, testPart, new Object[0]);
                vec = evaluation.predictions();
                double vals3[] = DPLIB.getResults(vec);
                double vals4[] = DPLIB.getMeasures(vals3);
                
                pop.add(new GIS_Chrm(trSet, vals2, vals, vals3, vals4));                                               
            }
            
            pop = DPLIB.MySort(pop);            
            
            int cnt = 0;
            int g = 0;
            for (g = 0; g < numGens; g++) {
                
                for(int i= 0;i<pop.size();i++)
                {
                    GIS_Chrm chrm = (GIS_Chrm)pop.get(i);
                    retVal = DPLIB.getStats(chrm.ds, false, false, false);
                    fout.write("#POPITNFO;;gn="+String.valueOf(g)+";;prt="+String.valueOf(p)+";;For="+name+"@"+":"+retVal+"\n");
                    fout.write("#POPITVALS;;gn="+String.valueOf(g)+";;prt="+String.valueOf(p)+";;For="+name+"@"+":"+"rpaf="+Arrays.toString(chrm.fitness).replace(", ", ",")
                            +";;conf="+Arrays.toString(chrm.conf).replace(", ", ",")+";;fit="+String.valueOf(chrm.getFitness())+";;TConf2="+Arrays.toString(chrm.testConf).replace(", ", ",")+";;TRpaf2="+Arrays.toString(chrm.testFitness).replace(", ", ",")+"\n");
                    fout.flush();
                    retVal = null;
                }
                
                ArrayList<IChrm> popNEW = new ArrayList();
                
                for (int i = 0; i < sizeTopP; i++) {
                    popNEW.add(pop.get(i));
                }
                for (int i = 0; i < pop.size() - sizeTopP; i += 2) {
                    int idx1 = 0;
                    int idx2 = 0;
                    while (idx1 == idx2) {
                        if (cnt >= 3) {
                            idx1 = DPLIB.rnd.nextInt(pop.size());
                            idx2 = DPLIB.rnd.nextInt(pop.size());
                        } else {
                            idx1 = GA.tornament(pop);
                            idx2 = GA.tornament(pop);
                            cnt++;
                        }
                    }
                    cnt = 0;
                    Instances ds1 = ((GIS_Chrm) pop.get(idx1)).ds;
                    Instances ds2 = ((GIS_Chrm) pop.get(idx2)).ds;

                    Instances[] ret = GA.crossOver(ds1, ds2,fixedTrainSize);
                    ds1 = ret[0];
                    ds2 = ret[1];
                    ds1 = GA.Mutate(ds1);
                    ds2 = GA.Mutate(ds2);
                    popNEW.add(new GIS_Chrm(ds1, null, null,null,null));
                    popNEW.add(new GIS_Chrm(ds2, null, null,null,null));
                }
                
                
                for (int i = 0; i < popNEW.size(); i++) {
                    J48 l = new J48();
                    
                    l.buildClassifier(((GIS_Chrm) popNEW.get(i)).ds);
                    Evaluation evaluation = new Evaluation(((GIS_Chrm) popNEW.get(i)).ds);
                    
                    if (vSet != null)
                    {
                        evaluation.evaluateModel(l, vSet, new Object[0]);
                    }
                    else
                    {
                        evaluation.evaluateModel(l, ((GIS_Chrm) popNEW.get(i)).ds, new Object[0]);
                    }
                    
                    ArrayList<Prediction> vec = evaluation.predictions();
                    vals = DPLIB.getResults(vec);
                    evaluation = new Evaluation(((GIS_Chrm) popNEW.get(i)).ds);
                    evaluation.evaluateModel(l, testPart, new Object[0]);
                    vec = evaluation.predictions();
                    double vals3[] = DPLIB.getResults(vec);
                    double vals4[] = DPLIB.getMeasures(vals3);
                    
                    ((GIS_Chrm) popNEW.get(i)).conf = Arrays.copyOf(vals, vals.length);
                    ((GIS_Chrm) popNEW.get(i)).testConf = vals3;
                    ((GIS_Chrm) popNEW.get(i)).testFitness = vals4;
                    
                    vals = DPLIB.getMeasures(vals);

                    ((GIS_Chrm) popNEW.get(i)).fitness = Arrays.copyOf(vals, vals.length);
                }
                
                popNEW = DPLIB.MySort(popNEW);
                boolean exit = false;
                int countComp = 0;
                
                ArrayList<ArrayList<IChrm>> rets = DPLIB.CombinePops(pop, popNEW);
                
                ArrayList<IChrm> del = rets.get(1);
                for(int i=0;i<del.size();i++)
                {
                    GIS_Chrm chrm = (GIS_Chrm)del.get(i);
                    retVal = DPLIB.getStats(chrm.ds, false, false, false);
                    fout.write("#POPDELITNFO;;gn="+String.valueOf(g)+";;prt="+String.valueOf(p)+";;For="+name+"@"+":"+retVal+";;rpaf="+Arrays.toString(chrm.fitness).replace(", ", ",")
                            +";;conf="+Arrays.toString(chrm.conf).replace(", ", ",")+";;fit="+String.valueOf(chrm.getFitness())+";;TConf2="+Arrays.toString(chrm.testConf).replace(", ", ",")+";;TRpaf2="+Arrays.toString(chrm.testFitness).replace(", ", ",")
                            +"\n");
                    fout.flush();
                    retVal = null;
                }
                
                del = null;
                
                popNEW = rets.get(0);
                double diff = Math.abs(GA.GetMeanFittness(pop, countComp) - GA.GetMeanFittness(popNEW, countComp));
                pop = popNEW;
                                              
                diffp.add(diff);
                if (diff < 1.0E-4D) {
                    exit = true;
                }
                if ((((GIS_Chrm) pop.get(0)).getFitness() > 0.0D) && (exit)) {
                    break;
                }
                exit = false;
            }
            diffs.add(diffp);
            ArrayList<Double> w = new ArrayList();
            if (count == 0) {
                count = pop.size();
            }
            for (int i = 0; i < count; i++) {

                J48 l = new J48();
                Instances tds = ((GIS_Chrm) pop.get(i)).ds;
                Instances testPartI = testPart;
                l.buildClassifier(tds);
                Evaluation evaluation = new Evaluation(tds);
                evaluation.evaluateModel(l, testPartI, new Object[0]);
                ArrayList<Prediction> vec = evaluation.predictions();
                
                retVal = DPLIB.getStats(tds, true, true, true);            
                fout.write("#TRPRTNFO;;prt="+String.valueOf(p)+";;For="+name+"@"+":"+retVal+"\n");
                
                retVal = DPLIB.getStats(testPart,true,true, true);            
                fout.write("#TSTPRTNFO;;prt="+String.valueOf(p)+";;For="+name+"@"+":"+retVal+"\n");
                vals = DPLIB.getResults(vec);
                
                fout.write("#TSTPRTVALS;;prt="+String.valueOf(p)+";;For="+name+"@"+":"+
                        "rpaf="+Arrays.toString(DPLIB.getMeasures(vals)).replace(", ", ",")
                            +";;conf="+Arrays.toString(vals).replace(", ", ",")+"\n");
                fout.flush();
                retVal = null;
                if (preds.size() == count) {
                    preds.get(i).addAll(vec);
                } else {
                    preds.add(vec);
                }
                w.add(Double.valueOf(((GIS_Chrm) pop.get(i)).getFitness()));
            }
            uinds = null;
        }

        vals = DPLIB.getResultsSet(preds, testSet, false);
        double vc[] = Arrays.copyOf(vals, vals.length);
        vals = DPLIB.getMeasures(vals);
        
        fout.write(name + "@" + ";;Vals="+Arrays.toString(vals).replace(", ", ",")+"\n");

        String diffsStr = "";
        for (int i = 0;i<diffs.size();i++)
        {
            diffsStr+=Arrays.toString(diffs.get(i).toArray(new Double[1])).replace(", ", ",")+"--";
        }
        
        endtime = System.currentTimeMillis();
        fout.write("Time;;" + name + "@" +  ":" + String.valueOf(endtime - starttime)+"\n");
        fout.write("VC-Raw;;" + name + "@" + ":" + Arrays.toString(vc).replace(", ", ",")+"\n");
        
        fout.flush();
        retVal = null;
        
        
    }
}
