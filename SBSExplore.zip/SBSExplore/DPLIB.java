/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SBSExplore;

import java.io.File;
import weka.core.*;
import java.io.FileReader;
import java.util.*;
import weka.attributeSelection.AttributeSelection;
import weka.classifiers.Evaluation;
import weka.classifiers.evaluation.NominalPrediction;
import weka.core.neighboursearch.LinearNNSearch;

import weka.attributeSelection.*;
import weka.classifiers.evaluation.Prediction;
import weka.classifiers.trees.J48;

/**
 *
 * @author sehossei
 */
public class DPLIB {

    //public static MathFuncs mf = new MathFuncs();
    public static int[] featuresCKLOC;
    public static int[] featuresALL;
    public static String dp;
    static double cf = 0.5;

    public static double infoGainCount = 0.5;
    public static boolean useIterativeInfoGainSubsetting = true;

    public static Random rnd = new Random(System.currentTimeMillis());

    public static int find(int[] arr, int val) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == val) {
                return i;
            }
        }
        return -1;

    }

    public static boolean findB(int[] arr, int val) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == val) {
                return true;
            }
        }
        return false;
    }

    public static String[] getFiles(String path) {
        
        File dir = new File(path);
        ArrayList<String> ret = new ArrayList<String>();
        File[] filesList = dir.listFiles();
        for (File f : filesList) {
            System.out.println(f.getName());
            if (f.isDirectory()) {
                continue;
            }
            if (f.isFile()) {
                if (f.getName().indexOf(".arff") > 0) {
                    ret.add(f.getName());
                } else {
                    continue;
                }
            }
        }
        return ret.toArray(new String[1]);
    }

    public static String[] getFiles(String path, String ext) {
        File dir = new File(path);
        ArrayList<String> ret = new ArrayList<String>();
        File[] filesList = dir.listFiles();
        for (File f : filesList) {
            if (f.isDirectory()) {
                continue;
            }
            if (f.isFile()) {
                if (f.getName().endsWith(ext)) {
                    ret.add(f.getName());
                }
            }
        }
        return ret.toArray(new String[1]);
    }

    public static int[] getTopX(int indi[]) throws Exception {

        int count = (int) (indi.length * infoGainCount);
        if (indi[indi.length - 1] != indi.length - 1) {
            throw new Exception("Incorrect Attribute");
        }

        int indis2[] = new int[count + 1];
        for (int i = 0; i < count; i++) {
            indis2[i] = indi[i];
        }

        indis2[indis2.length - 1] = indi[indi.length - 1];

        return indis2;
    }

    public static Instances LoadCSV(String file, String dp, int ft[]) throws Exception {

        ArrayList<String> files = new ArrayList<String>();
        files.add(file);
        return DPLIB.LoadCSV(files, dp, ft);

    }

    public static Instances LoadCSV(ArrayList<String> files, String dp, int ft[]) throws Exception {
        int id = 0;
        try {
            Arrays.sort(ft);

            String f = files.get(0);
            FileReader file = new FileReader(dp + f);
            Instances insts = new Instances(file);
            int numAttrs = insts.numAttributes();
            insts.delete();
            int skipPercent = 0, loadPercent = 100;
            for (String f2 : files) {
                String f1 = f2.trim();
                file = new FileReader(dp + f1);
                Instances data = new Instances(file);

                int num = data.numInstances();
                for (int i = (int) (num * skipPercent / 100.0); i < (int) (num * loadPercent / 100.0); i++) {
                    //MyInstance tins = (MyInstance) data.instance(i);
                    //tins.id = id; 

                    data.instance(i).SetID(f1.substring(0, f1.length() - 5) + "@" + String.valueOf(i));// + ";DatasetName=" + String.join(",", files) + "@";
                    //data.instance(i).extra = "I=" + String.valueOf((int) data.instance(i).classValue());
                    data.instance(i).SetInstIndex(id);
                    insts.add(data.instance(i));
                    id++;
                }

            }

            for (int i = 0; i < numAttrs - 1; i++) {
                int attrInd = numAttrs - 1 - 1 - i;

                if (!findB(ft, attrInd)) {
                    insts.deleteAttributeAt(attrInd);
                }
            }
            numAttrs = ft.length;

            int num = insts.numInstances();
            for (int i = 0; i < num; i++) {

                double[] lst = insts.instance(i).toDoubleArray();
            }

            num = insts.numInstances();
            for (int i = 0; i < num; i++) {
                if (insts.instance(i).value(numAttrs - 1) > 0) {

                    insts.instance(i).setValue(numAttrs - 1, 1);
                    insts.instance(i).SetExtra("1");
                } else {
                    insts.instance(i).setValue(numAttrs - 1, 0);
                    insts.instance(i).SetExtra("0");
                }
            }
            insts.setClassIndex(numAttrs - 1);
            return insts;

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(files);
            System.err.println("Load");
        }
        return null;
    }

    public static double[] getResults(ArrayList<Prediction> vec) {
        double tp = 0.0, fp = 0.0, tn = 0.0, fn = 0.0;
        for (int p = 0; p < vec.size(); p++) {

            NominalPrediction np = (NominalPrediction) vec.get(p);

            double geo = np.actual();
            double res = np.distribution()[1];

            if (geo >= cf) {
                geo = 1;
            } else {
                geo = 0;
            }

            if (res >= cf) {
                res = 1;
            } else {
                res = 0;
            }

            if (geo == 0 && res == 0) {
                tn += 1;
            } else if (geo > 0 && res > 0) {
                tp += 1;
            } else if (geo == 0 && res > 0) {
                fp += 1;
            } else if (geo > 0 && res == 0) {
                fn += 1;
            }

        }

        return new double[]{tp, tn, fp, fn};
    }

    public static String getStats(Instances set, boolean extIDS, boolean extExts, boolean extChrs) {
        MathFuncs mf = new MathFuncs();
        String retVal = "";

        if (extChrs) {
            double res[] = null;
            double numbers[] = new double[set.numInstances()];
            double tres[];
            for (int i = 0; i < set.numAttributes(); i++) {
                for (int j = 0; j < numbers.length; j++) {
                    numbers[j] = set.instance(j).value(i);
                }
                mf.set(numbers);
                tres = mf.getallDistChars();
                if (res == null) {
                    res = new double[set.numAttributes() * tres.length];
                }
                for (int j = 0; j < tres.length; j++) {
                    res[i * tres.length + j] = tres[j];
                }
                tres = null;
            }

            retVal += "DstChr=" + Arrays.toString(res).replace(", ", ",") + ";;";
            
            numbers = null;
            res = null;
            tres = null;
            
        }
        int classCounts[] = new int[2];
        for (int i = 0; i < set.numInstances(); i++) {
            if (set.instance(i).classValue() > Consts.ep) {
                classCounts[1]++;
            } else {
                classCounts[0]++;
            }
        }

        
        
        retVal += "ClsCnt=" + Arrays.toString(classCounts).replace(", ", ",");

        String ids[] = null;
        if (extIDS) {
            ids = new String[set.numInstances()];
            for (int i = 0; i < set.numInstances(); i++) {
                ids[i] = set.instance(i).GetID();
            }
        }

        String exts[] = null;
        if (extExts) {
            exts = new String[set.numInstances()];
            for (int i = 0; i < set.numInstances(); i++) {
                exts[i] = set.instance(i).GetExtra();
            }
        }
        
        int countMutation = 0;
        int countCross = 0;
        int countChangedLabel = 0;
        int countBothCM = 0;
        int countMCnoChange=0;
        int countMultiMut = 0;
        int countMultiCross = 0;
        int countNoMC = 0;
        
        String extr;
        for (int i = 0; i < set.numInstances(); i++) {
            extr = set.instance(i).GetExtra();
            int len = extr.length();
            boolean hasmut = false;
            boolean hascross = false;
            boolean hasmultimute = false;
            boolean hasmulticross = false;
            if (len>1)                
            {
                if( extr.charAt(0)!=extr.charAt(len-1))
                {
                    countChangedLabel += 1;
                    
                }                                
                
                if (extr.indexOf("M")>0)
                {
                    hasmut = true;
                    countMutation+=1;
                    
                    if (extr.indexOf("M")!=extr.lastIndexOf("M"))
                    {
                        hasmultimute = true;
                        countMultiMut+=1;
                    }                    
                }
                                
                
                if (extr.indexOf("C")>0)
                {
                    hascross = true;
                    countCross+=1;
                    
                    if (extr.indexOf("C")!=extr.lastIndexOf("C"))
                    {
                        hasmulticross = true;
                        countMultiCross+=1;
                    }
                }
                                               
                
                if (hasmut && hascross)
                {
                    countBothCM+=1;                                            
                }
                
                if (!hasmut && !hascross)
                {
                    countNoMC+=1;
                }
                
                
                if ((hasmut && hascross) || hasmultimute || hasmulticross)
                {
                    if (extr.charAt(0)==extr.charAt(len-1))
                    {
                        countMCnoChange+=1;
                    }
                }
            }
            else
            {
                countNoMC+=1;
            }
        }
        
        
        
        retVal+=";;Counts="+Arrays.toString(new int[] {countMutation,
        countCross,
        countChangedLabel,
        countBothCM,
        countMCnoChange,
        countMultiMut,
        countMultiCross,
        countNoMC}).replace(", ", ",");
        
        if (extIDS) {
            retVal += ";;" + "IDS=" + Arrays.toString(ids).replace(", ", ",");

            ids = null;
        }
        if (extExts) {
            retVal += ";;" + "EXTS=" + Arrays.toString(exts).replace(", ", ",");
            exts = null;
        }

        return retVal;

    }

    public static double[] getResultsSet(ArrayList<ArrayList<Prediction>> preds, Instances tss, boolean cluster) throws Exception {
        double tp = 0.0, fp = 0.0, tn = 0.0, fn = 0.0;

        int num = tss.numInstances();
        int numAttrs = tss.numAttributes();

        for (int i = 0; i < num; i++) {
            double geo = tss.instance(i).value(numAttrs - 1);

            ArrayList<Double> lss = new ArrayList<Double>();

            for (int k = 0; k < preds.size(); k++) {
                double v = ((NominalPrediction) preds.get(k).get(i)).distribution()[1];

                lss.add(v);
            }

            double res = 0;
            if (cluster) {
                //Cluster the results. For ensembles. Not implemented
            } else {
                for (double val : lss) {
                    res += val;
                }
                res /= lss.size();

            }

            if (geo >= cf) {
                geo = 1;
            } else {
                geo = 0;
            }

            if (res >= cf) {
                res = 1;
            } else {
                res = 0;
            }

            if (geo == 0 && res == 0) {
                tn += 1;
            } else if (geo > 0 && res > 0) {
                tp += 1;
            } else if (geo == 0 && res > 0) {
                fp += 1;
            } else if (geo > 0 && res == 0) {
                fn += 1;
            }
        }

        return new double[]{tp, tn, fp, fn};
    }

    public static ArrayList<IChrm> POP_SORT(ArrayList<IChrm> hmm) {
        for (int i = 0; i < hmm.size() - 1; i++) {
            for (int j = i + 1; j < hmm.size(); j++) {
                if (hmm.get(i).getFitness() < hmm.get(j).getFitness()) {
                    IChrm tmp = hmm.get(i);
                    hmm.set(i, hmm.get(j));
                    hmm.set(j, tmp);
                }
            }
        }
        return hmm;
    }

    public static ArrayList<IChrm> MySort(ArrayList<IChrm> hmm) {

        Collections.sort(hmm, (IChrm t, IChrm t1) -> {
            double tf1 = t.getFitness();
            double tf2 = t1.getFitness();
            if (tf1 < tf2) {
                return 1;
            } else if (tf1 > tf2) {
                return -1;
            } else {
                return 0;
            }
        });

        return hmm;
    }

    public static Instances fSelectSet(Instances set, int[] indices) throws Exception {
        Instances nS = new Instances(set);
        for (int i = nS.numAttributes() - 2; i >= 0; i--) {
            if (!findB(indices, i)) {
                nS.deleteAttributeAt(i);
            }
        }
        return nS;
    }

    public static int[] fSelectInfoGain(Instances train) throws Exception {

        AttributeSelection attsel = new AttributeSelection();
        InfoGainAttributeEval eval = new InfoGainAttributeEval();

        Ranker r = new Ranker();
        attsel.setSearch(r);
        attsel.setEvaluator(eval);

        attsel.SelectAttributes(train);

        int[] indices = attsel.selectedAttributes();

        return indices;
    }

    public static int[] iterativeInfoGainSubsetting(Instances trainSet, int ranks[]) throws Exception {
        int folds = 10;
        double f = 0;
        Instances trset = new Instances(trainSet);
        trset.stratify(folds);
        int count = 2;

        int tranks[] = null;
        while (count < ranks.length - 1) {
            double vals[] = null;

            for (int i = 0; i < folds; i++) {
                tranks = new int[count + 1];
                for (int j = 0; j < count; j++) {
                    tranks[j] = ranks[j];
                }

                tranks[count] = ranks[ranks.length - 1];
                Instances trCV = DPLIB.fSelectSet(trset.trainCV(folds, i), tranks);
                Instances tsCV = DPLIB.fSelectSet(trset.testCV(folds, i), tranks);
//                J48 nb = new J48();
                 J48 l = new J48();

                l.buildClassifier(trCV);
                Evaluation eval = new Evaluation(trCV);
                eval.evaluateModel(l, tsCV);
                ArrayList<Prediction> vec = eval.predictions();

                if (vals == null) {
                    vals = DPLIB.getResults(vec);
                } else {
                    double[] v2 = DPLIB.getResults(vec);
                    for (int k = 0; k < v2.length; k++) {
                        vals[k] += v2[k];
                    }
                }
            }
            
            vals = DPLIB.getMeasures(vals);
            if (f < vals[vals.length - 1]) {
                f = vals[vals.length - 1];
                count++;
            } else {
                break;
            }
        }
        return tranks;
    }

    public static ArrayList<ArrayList<IChrm>> CombinePops(ArrayList<IChrm> hmm, ArrayList<IChrm> newHMM) {
        int i = 0;
        int j = 0;
        ArrayList<IChrm> ret = new ArrayList<IChrm>();
        ArrayList<IChrm> del = new ArrayList<IChrm>();
        while (ret.size() < hmm.size()) {
            if (hmm.get(i).getFitness() >= newHMM.get(j).getFitness()) {
                ret.add(hmm.get(i));
                i += 1;
            } else {
                ret.add(newHMM.get(j));
                j += 1;
            }
        }

        while (del.size() < hmm.size()) {
            if (i < hmm.size() && j < newHMM.size()) {

                if (hmm.get(i).getFitness() >= newHMM.get(j).getFitness()) {
                    del.add(hmm.get(i));
                    i += 1;

                } else {
                    del.add(newHMM.get(j));
                    j += 1;

                }
            } else if (i < hmm.size()) {
                del.add(hmm.get(i));
                i += 1;
            } else {
                del.add(newHMM.get(j));
                j += 1;
            }
        }
        ArrayList<ArrayList<IChrm>> retful = new ArrayList<ArrayList<IChrm>>();
        retful.add(ret);
        retful.add(del);
        return retful;
    }

    public static double[] getMeasures(double[] vals) throws Exception {
        double tp = vals[0], tn = vals[1], fp = vals[2], fn = vals[3];
        double prec = 0.0, accu = 0.0, recall = 0.0, gm = 0.0, bac = 0.0;
        if (tp + fn != 0) {
            recall = tp / (tp + fn);
        }

        if (tp + fp != 0) {
            prec = tp / (tp + fp);
        }

        accu = 0;

        double F = 0;
        if (prec + recall != 0) {
            F = (2.0 * prec * recall) / (prec + recall);
        }

        double retVals[] = {recall, prec, accu, F};
        for (int i = 0; i < retVals.length; i++) {
            retVals[i] = Math.floor(retVals[i] * 1000.0) / 1000.0;
        }

        return retVals;
    }

    public static Instances List2Instances(ArrayList<Double> data) {

        int numInstances = data.size();
        int numDimensions = 1;
        FastVector atts = new FastVector();
        ArrayList<Instance> instances = new ArrayList<Instance>();
        for (int dim = 0; dim < numDimensions; dim++) {
            Attribute current = new Attribute("Attribute" + String.valueOf(dim), dim);
            if (dim == 0) {
                for (int obj = 0; obj < numInstances; obj++) {
                    instances.add(new SparseInstance(numDimensions));
                }
            }

            for (int obj = 0; obj < numInstances; obj++) {
                instances.get(obj).setValue(current, data.get(obj));
            }

            atts.addElement(current);
        }
        Instances newDataset = new Instances("Dataset", atts, atts.size());

        for (Instance inst : instances) {
            newDataset.add(inst);
        }
        return newDataset;
    }

    public static Instances NNFilter(Instances train, Instances test, int count) throws Exception {

        Instances trainCopy = new Instances(train);
        Instances testCopy = new Instances(test);
        trainCopy.setClassIndex(-1);
        testCopy.setClassIndex(-1);
        trainCopy.deleteAttributeAt(trainCopy.numAttributes() - 1);
        testCopy.deleteAttributeAt(testCopy.numAttributes() - 1);
        Instances out = new Instances(train, 0);
        LinearNNSearch knn = new LinearNNSearch(trainCopy);

        Set<Integer> instSet = new HashSet<Integer>();
        Set<String> instSetStr = new HashSet<String>();
        String ID = "";
        for (int i = 0; i < test.numInstances(); i++) {
            Instances nearestInstances = knn.kNearestNeighbours(testCopy.instance(i), count);

            for (int j = 0; j < Math.min(nearestInstances.numInstances(), count); j++) {

                ID = nearestInstances.instance(j).GetID();

                if (instSetStr.contains(ID)) {
                    continue;
                }
                out.add(train.instance(nearestInstances.instance(j).GetInstIndex()));
                instSetStr.add(ID);

            }

        }
        return out;
    }

    public static Instances NNFilterMulti(Instances train, Instances test, int count) throws Exception {

        if (count == 0) {
            count = 1;
        }
        Instances trainCopy = new Instances(train);
        Instances testCopy = new Instances(test);
        trainCopy.setClassIndex(-1);
        testCopy.setClassIndex(-1);
        trainCopy.deleteAttributeAt(trainCopy.numAttributes() - 1);
        testCopy.deleteAttributeAt(testCopy.numAttributes() - 1);
        Instances out = new Instances(train, 0);
        out.delete();
        LinearNNSearch knn = new LinearNNSearch(trainCopy);
        knn.setDistanceFunction(new EuclideanDistance(trainCopy));

        String ID = "";
        Set<String> instSetStr = new HashSet<>();
        for (int i = 0; i < test.numInstances(); i++) {
            Instances nearestInstances = knn.kNearestNeighbours(testCopy.instance(i), count);
            int retCount = nearestInstances.numInstances();
            retCount = Math.min(retCount, count);
            for (int j = 0; j < retCount; j++) {
                
                ID = nearestInstances.instance(j).GetID();
                if (instSetStr.contains(ID)) {
                    continue;
                }
                out.add(train.instance(nearestInstances.instance(j).GetInstIndex()));
                instSetStr.add(ID);
            }

        }

        knn.setDistanceFunction(new ChebyshevDistance(trainCopy));

        for (int i = 0; i < test.numInstances(); i++) {
            Instances nearestInstances = knn.kNearestNeighbours(testCopy.instance(i), count);
            int retCount = nearestInstances.numInstances();
            retCount = Math.min(retCount, count);
            for (int j = 0; j < retCount; j++) {
                ID = nearestInstances.instance(j).GetID();
                if (instSetStr.contains(ID)) {
                    continue;
                }
                out.add(train.instance(nearestInstances.instance(j).GetInstIndex()));
                instSetStr.add(ID);
            }

        }

        knn.setDistanceFunction(new ManhattanDistance(trainCopy));

        for (int i = 0; i < test.numInstances(); i++) {
            Instances nearestInstances = knn.kNearestNeighbours(testCopy.instance(i), count);
            int retCount = nearestInstances.numInstances();
            retCount = Math.min(retCount, count);
            for (int j = 0; j < retCount; j++) {

                ID = nearestInstances.instance(j).GetID();

                if (instSetStr.contains(ID)) {
                    continue;
                }
                out.add(train.instance(nearestInstances.instance(j).GetInstIndex()));
                instSetStr.add(ID);
            }

        }
        instSetStr = null;
        return out;
    }

    public static int FindInstanceIndex(Instance ins, Instances set) {

        for (int i = 0; i < set.numInstances(); i++) {
            boolean eq = true;
            for (int j = 0; j < ins.numAttributes(); j++) {
                if (ins.value(j) != set.instance(i).value(j)) {
                    eq = false;
                    break;

                }
            }
            if (eq) {
                return i;
            }
        }
        return -1;
    }

    public static int FindInstanceIndexSimple(Instance ins) {

        return ins.GetInstIndex();
    }

    public static HashSet<Integer> FindAllSimilarInstancesIndexes(int index, Instances set) {

        
        
        HashSet<Integer> indexSet = new HashSet<Integer>();
        Instance ins = set.instance(index);

        for (int i = 0; i < set.numInstances(); i++) {

            if (ins.GetID().compareTo(set.instance(i).GetID()) == 0) {
                indexSet.add(i);
            }
        }
        return indexSet;
    }
}
