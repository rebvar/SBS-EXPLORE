import pandas as pd
print (pd.__version__)
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm
from statsmodels.graphics.factorplots import interaction_plot
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns


sns.set(style="whitegrid")
sns.set_style(style="white")
sns.set(font_scale=1.4)
basePath = "D:/GISOUT/GIS_EXPLORE_DATA_PLT"
# Draw a pointplot to show pulse as a function of three categorical factors

import rpy2
from rpy2 import robjects as robjs

r = robjs.r


pd.set_option('display.float_format', lambda x: '%.5f' % x)

measureTexts = {'GMean1':'GMean','GMean2':'GMean 2','bal':'BALANCE','F':'F-MEASURE','rec':'RECALL','prec':'PRECISION','tnr':'TNR','fnr':'FNR','mcc':'MCC','F0.5':'F0.5','F2':'F2','pf':'PF','fit':'FITNESS'}
def eta_squared(aov):
    aov['eta_sq'] = 'NaN'
    aov['eta_sq'] = aov[:-1]['sum_sq']/sum(aov['sum_sq'])
    return aov
 
def omega_squared(aov):
    mse = aov['sum_sq'][-1]/aov['df'][-1]
    aov['omega_sq'] = 'NaN'
    aov['omega_sq'] = (aov[:-1]['sum_sq']-(aov[:-1]['df']*mse))/(sum(aov['sum_sq'])+mse)
    return aov

def PerMeasurePerDataFuncOnlyGisAnova():
    

    dft1 = pd.DataFrame.from_csv('NaiveBayes-GMean1mcc--data_df.csv')
    dft2 = pd.DataFrame.from_csv('NaiveBayes-FGMean1--data_df.csv')
    dft3 = pd.DataFrame.from_csv('J48-FGMean1--data_df.csv')
    

    dfall3 = dft1.copy()

    dfall3 = dfall3.append(dft2)
    dfall3 = dfall3.append(dft3)


    #df = pd.concat([df1,df2,df3])
    dfall3.to_csv('3df.csv')

    df12 = dft1.copy()
    df12 = df12.append(dft2)
    
    df12.to_csv('2df-Fitness-Dif.csv')

    df23 = dft2.copy()    
    df23 = df23.append(dft3)

    df23.to_csv('2df-Learner-Dif.csv')

    hdrs = list(dft1.columns.values)
    measures = hdrs[:hdrs.index('vType')]
    

    dfnames = ['All3--','FitnessDif-2--','LearnerDif-2--']

    funcs3 = [[
               ' ~ C(LRN)',
             ' ~ C(trType)',
             ' ~ C(LRN) * C(trType)',
             ' ~ C(FITFUNC)', 
             ' ~ C(LRN) * C(FITFUNC)', 
             ' ~ C(vType)', 
             ' ~ C(LRN) * C(FITFUNC) * C(vType)',
             ' ~ C(LRN) * C(FITFUNC) * C(trType) * C(vType)',
             ' ~ C(FITFUNC) * C(trType)', 
             ' ~ C(FITFUNC) * C(vType)', 
             ' ~ C(LRN) * C(vType)'
             ]
              ,              
             [
              ' ~ C(trType)',             
             ' ~ C(FITFUNC)',             
             ' ~ C(vType)', 
             ' ~ C(FITFUNC) * C(vType)',
             ' ~ C(FITFUNC) * C(trType) * C(vType)',
             ' ~ C(FITFUNC) * C(trType)'
             ]
             ,
             [' ~ C(LRN)',
              ' ~ C(trType)',
             ' ~ C(LRN) * C(trType)',             
             ' ~ C(vType)', 
             ' ~ C(LRN) * C(vType)',
             ' ~ C(LRN) * C(trType) * C(vType)',
             ' ~ C(LRN) * C(vType)'
             ]
             ]



    for index, df1 in enumerate([dfall3,df12,df23]):
        anovfor = dfnames[index]
        print ('Anova for ', anovfor)
        funcs = funcs3[index]


        for func in funcs:
            fname = 'NEW--'+anovfor+'AnovaOut-'+func.replace('*','-=times=-')
            anovFile = open(fname+'.txt','w')
            for m in measures:
                try:
                    if m.find('.')>=0:
                        continue
                    mod = ols(m+func,
                            data=df1).fit()
                    
                    resid = list(mod.resid)
                    stats.probplot(resid, dist="norm", plot=plt)
                    plt.savefig(pltPath+'QQ-Before-'+anovfor+'-- '+m+'--VType.jpg', dpi = 300)

                    resid = list(mod2.resid)
                    stats.probplot(resid, dist="norm", plot=plt)
                    plt.savefig(pltPath+'QQ-After-'+anovfor+'-- '+m+'--VType.jpg', dpi = 300)

        

                    aov_table = sm.stats.anova_lm(mod, typ=2)
                    
                    eta_squared(aov_table)
                    omega_squared(aov_table)

                    #aov_table.round(4)
                    
                    anovFile.write('-----For Measure: '+measureTexts[m]+'-------\n\n')
                    anovFile.write (aov_table.to_string())

                    anovFile.write('\n\n-------------------------------------------\n\n\n\n')
                    print ('Anova For', m)
                    fparts = func.replace('C(','').replace(')','').replace('~','').replace(' ','').split('*')
                    if len(fparts)>3:
                        g = sns.factorplot(x=fparts[0], y=m, hue=fparts[1],col = fparts[2],row = fparts[3],  data=df1, capsize=.2, palette="YlGnBu_d", size=6, aspect=.5)
                        g.despine(left=True)
                        #g.set(ylim=(0, 1))
                        plt.savefig(basePath+'/ANOVPL/'+fname+'--'+m+'.eps',format = 'eps', dpi = 1000)
                        plt.savefig(basePath+'/ANOVPL/'+fname+'--'+m+'.jpg',format = 'jpg', dpi = 100)
                    
                    elif len(fparts)>2:
                        g = sns.factorplot(x=fparts[0], y=m, hue=fparts[1],col = fparts[2],  data=df1, capsize=.2, palette="YlGnBu_d", size=6, aspect=.75)
                        g.despine(left=True)
                        #g.set(ylim=(0, 1))
                        plt.savefig(basePath+'/ANOVPL/'+fname+'--'+m+'.eps',format = 'eps', dpi = 1000)
                        plt.savefig(basePath+'/ANOVPL/'+fname+'--'+m+'.jpg',format = 'jpg', dpi = 100)
                    elif len(fparts)>1:
                        g = sns.factorplot(x=fparts[0], y=m, hue=fparts[1],  data=df1, capsize=.2, palette="YlGnBu_d", size=6, aspect=.75)
                        g.despine(left=True)
                        #g.set(ylim=(0, 1))
                        plt.savefig(basePath+'/ANOVPL/'+fname+'--'+m+'.eps',format = 'eps', dpi = 1000)
                        plt.savefig(basePath+'/ANOVPL/'+fname+'--'+m+'.jpg',format = 'jpg', dpi = 100)
                    else:
                        g = sns.factorplot(x=fparts[0], y=m,  data=df1, capsize=.2, palette="YlGnBu_d", size=6, aspect=.75)
                        g.despine(left=True)
                        #g.set(ylim=(0, 1))
                        plt.savefig(basePath+'/ANOVPL/'+fname+'--'+m+'.eps',format = 'eps', dpi = 1000)
                        plt.savefig(basePath+'/ANOVPL/'+fname+'--'+m+'.jpg',format = 'jpg', dpi = 100)
                        
                except Exception as ex:
                    print ('ERROR for '+measureTexts[m]+' in '+anovfor+'  ', func,'  :::  ',ex)
                    anovFile.write('-----For Measure: '+measureTexts[m]+'-------\n\n')
                    anovFile.write('\n\n-------------ERROR ------------------------------\n\n\n\n')

                    anovFile.write(str(ex))

                    anovFile.write('\n\n-------------------------------------------\n\n\n\n')
                #input()
            anovFile.close()


PerMeasurePerDataFuncOnlyGisAnova()
