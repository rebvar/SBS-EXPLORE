Path = 'D:/GISOUT/1NEWEXPLORE--J48,F-GMean1/'
fitFunc = Path[Path.find(',')+1:-1].split('-')
usedLrn = Path[Path.find('--')+2:Path.rfind(',')]
import os
import ast
import json

import numpy as np
import scipy
from scipy.stats import pearsonr, spearmanr
from scipy import special as ssp
import matplotlib
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import random
import seaborn
import math

basePath = "D:/GISOUT/GIS_EXPLORE_DATA_PLT"
if Path.find('--')>0:
    dataPath = basePath+'/Data'+Path[Path.find('--'):Path.find(',')]+','+Path[Path.find(',')+1:-1]+'/'
    dataPath = basePath+'/Data'+Path[Path.find('--'):Path.find(',')]+','+Path[Path.find(',')+1:-1]+'/'
    pltPath = basePath+'/PLT'+Path[Path.find('--'):Path.find(',')]+','+Path[Path.find(',')+1:-1]+'/'
else:
    dataPath = basePath+'/Data,'+Path[Path.find(',')+1:-1]+'/'
    pltPath = basePath+'/PLT,'+Path[Path.find(',')+1:-1]+'/'

if not os.path.exists(dataPath):
    os.makedirs(dataPath)
    
if not os.path.exists(pltPath):
    os.makedirs(pltPath)


def getMeasures(tp, tn, fp, fn):
    measures = {}
    if tp+fn!=0:
        measures['rec'] = tp/(tp+fn)
    else:
        measures['rec'] = 0

    if tp+fp!=0:
        measures['prec'] = tp/(tp+fp)
    else:
        measures['prec'] = 0


    if measures['rec']+measures['prec']>0:
        measures['F'] = 2*measures['rec']*measures['prec']/(measures['rec']+measures['prec'])        
    else:
        measures['F'] = 0
        
    if measures['rec']+4*measures['prec']>0:        
        measures['F2'] = 5*measures['rec']*measures['prec']/(measures['rec']+4*measures['prec'])        
    else:        
        measures['F2'] = 0
        
    if measures['rec']+0.25*measures['prec']>0:
        measures['F0.5'] = 1.25*measures['rec']*measures['prec']/(measures['rec']+0.25*measures['prec'])
    else:
        measures['F0.5'] = 0

    #if tp+fp+tn+fn!=0:
    #    measures['accu'] = (tp+tn)/(tp+fp+tn+fn)
    #else:
    #    measures['accu'] = 0
       
    if fp+tn!=0:
        measures['pf'] = (fp)/(fp+tn)
    else:
        measures['pf'] = 0
    
    #if measures['rec']+(1-measures['pf'])!=0:
    #    measures['G-Measure'] = 2*measures['rec']*(1-measures['pf'])/(measures['rec']+(1-measures['pf']))
    #else:
    #    measures['G-Measure'] = 0

    measures['bal'] = 1-(math.sqrt(measures['pf']*measures['pf']+(1-measures['rec'])*(1-measures['rec']))/math.sqrt(2))

    mcsq = math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))

    if mcsq!=0:
        measures['mcc'] = (tp*tn-fp*fn)/mcsq;
    else:
        measures['mcc'] = 0


    if tn+fp!=0:
        measures['tnr'] = tn/(tn+fp)
    else:
        measures['tnr'] = 0


    if fn+tp!=0:
        measures['fnr'] = fn/(fn+tp)
    else:
        measures['fnr'] = 0
    
    
    measures['GMean1'] = math.sqrt(measures['rec']*measures['prec'])
    measures['GMean2'] = math.sqrt(measures['rec']*(1-measures['pf']))
    

    #measures['FMCC'] = measures['F']*measures['mcc']
    
    fit = 1    
    for key in fitFunc:
        fit*=measures[key]
    measures['fit'] = fit

    return measures


a = [10,20,21,18]
t = getMeasures(*a)





def GetLineParts(line):
    if line.startswith('#'):
        ret = {}
        parts = line.split('@:')
        if len(parts)>2:
            print (line)
            raise Exception('line multipart')

        for part in parts:
            partParts = part.split(';;')
            for p in partParts:
                if p.find('=')<0:
                    continue
                ret[p[:p.find('=')]] = p[p.find('=')+1:]
        return ret
    else:
        return None


if os.path.exists(dataPath+'datasets.json'):
    with open(dataPath+'datasets.json') as file:
        datasets = json.load(file)
else:
    datasets = []
    for file in os.listdir(Path):    
        dataset = file[file.find('[') + 1:file.find(']')].replace('.arff','')
        if not dataset in datasets:
            datasets.append(dataset)
    datasets = sorted(datasets)

    #if not os.path.exists('datasets.json'):
    with open(dataPath+'datasets.json','w') as file:
        json.dump(datasets, file)

font = {'family' : 'normal',        
        'size'   : 23}

matplotlib.rc('font', **font)


matplotlib.rc('legend', fontsize=23)

plt.rcParams["axes.grid"] = True
methods = []

#data = {}

gisOptsSet = False
CHRMSize = None
NumGens = None
popSize = None
NumParts = None
iters = None
sizeTop = None
Learner = None



for file in os.listdir(Path):
    dataset = file[file.find('[') + 1:file.find(']')].replace('.arff','')
    dsId = datasets.index(dataset)
    data = {}
    
    if not os.path.exists(dataPath+str(dsId)+'.json'):
        print('Proc:',file)
        lines = []
        o = open(Path + file)
        
        if not dsId in data.keys():
            data[dsId] = {}
        lincnt = 0
        iternum = 0
        lineeq = False
        while True:
            lincnt+=1
            line = o.readline()
        
            if line == '':
                break
            linepre = line
            
            mtd = None
            line = line.replace('\n','')
            if len(line.strip()) == 0:
            
                continue

            if line.startswith('------------------------------------------'):
                continue
            elif line == '#':
                continue
            if line.startswith('#ITERINFO'):
                iterfile = line[line.find('=') + 1:line.find('-Iter')].replace('.arff','')
                if iterfile != dataset:
                    raise Exception('Invalid IterLine')
                iternum = int(line[line.rfind(':') + 1:])
            elif line.startswith('#GIS-OPTIONS;;'):
                mtd = line[line.find('=') + 1:line.find('@')]
                if not mtd in methods:
                    methods.append(mtd)
                
                if not mtd in data[dsId].keys():
                    data[dsId][mtd] = {}
                if not gisOptsSet:
                    line = line[line.find(':iters') + 1:].split('-')
                    line = [item[item.find('=') + 1:] for item in line]
                    CHRMSize = float(line[4])
                    NumGens = int(line[3])
                    popSize = int(line[1])
                    NumParts = int(line[2])
                    iters = int(line[0])
                    sizeTop = int(line[5])
                    Learner = line[6]
                    gisopts = [CHRMSize, NumGens, popSize, NumParts, iters, sizeTop, Learner]
                    with open(dataPath+'Opts.json','w') as optsFile:
                        json.dump(gisopts,optsFile)

            elif line.startswith('#VSETINFO;;'):
            
                parts = GetLineParts(line)
                mtd = parts['For']
                counts = ast.literal_eval(parts['ClsCnt'])
                if not 'vSetNfoClassCounts' in data[dsId][mtd].keys():
                   data[dsId][mtd]['vSetNfoClassCounts'] = []
                   data[dsId][mtd]['vSetNfoIDS'] = []
                   data[dsId][mtd]['vSetNfoDstChr'] = []

                data[dsId][mtd]['vSetNfoClassCounts'].append(counts)

                IDS = [(datasets.index(item[:item.find('@')]),int(item[item.find('@') + 1:])) for item in parts['IDS'][1:-1].split(',')]
                data[dsId][mtd]['vSetNfoIDS'].append(IDS)
            
                data[dsId][mtd]['vSetNfoDstChr'].append(ast.literal_eval(parts['DstChr']))
            
            elif line.startswith('#POPITNFO;;'):

                parts = GetLineParts(line)
                mtd = parts['For']
                counts = ast.literal_eval(parts['ClsCnt'])
                if not 'popItNfoClassCounts' in data[dsId][mtd].keys():
                    data[dsId][mtd]['popItNfoClassCounts'] = []
                    data[dsId][mtd]['popItNfoMCCounts'] = []                
                    data[dsId][mtd]['popGenInfo'] = {}
                if not iternum in data[dsId][mtd]['popGenInfo'].keys():
                    data[dsId][mtd]['popGenInfo'][iternum] = [[] for _ in range(NumParts)]
                data[dsId][mtd]['popItNfoClassCounts'].append(counts)
                data[dsId][mtd]['popItNfoMCCounts'].append(ast.literal_eval(parts['Counts']))
                prt = int(parts['prt'])
                gn = int(parts['gn'])

                if not gn in data[dsId][mtd]['popGenInfo'][iternum][prt]:
                    data[dsId][mtd]['popGenInfo'][iternum][prt].append(gn)

                

            elif line.startswith('#POPDELITNFO;;'):

                parts = GetLineParts(line)
                mtd = parts['For']
                counts = ast.literal_eval(parts['ClsCnt'])
                if not 'popdelItNfoClassCounts' in data[dsId][mtd].keys():
                    data[dsId][mtd]['popdelItNfoClassCounts'] = []
                    data[dsId][mtd]['popdelGenInfo'] = {}                
                    data[dsId][mtd]['popItdelNfoMCCounts'] = []
                    data[dsId][mtd]['popdelTConf2Mat'] = []                    
                    data[dsId][mtd]['popdelConfMat'] = []
                    data[dsId][mtd]['popdelfit'] = []
                if not iternum in data[dsId][mtd]['popdelGenInfo'].keys():
                    data[dsId][mtd]['popdelGenInfo'][iternum] = [[] for _ in range(NumParts)]
                data[dsId][mtd]['popdelItNfoClassCounts'].append(counts)
                data[dsId][mtd]['popItdelNfoMCCounts'].append(ast.literal_eval(parts['Counts']))
                prt = int(parts['prt'])
                gn = int(parts['gn'])
                if not gn in data[dsId][mtd]['popdelGenInfo'][iternum][prt]:
                    data[dsId][mtd]['popdelGenInfo'][iternum][prt].append(gn)
                
                
                data[dsId][mtd]['popdelConfMat'].append(ast.literal_eval(parts['conf']))
                
                data[dsId][mtd]['popdelTConf2Mat'].append(ast.literal_eval(parts['TConf2']))
                data[dsId][mtd]['popdelfit'].append(float(parts['fit']))

                

            elif line.startswith('#POPITVALS;;'):
            
                parts = GetLineParts(line)

                mtd = parts['For']
                conf = ast.literal_eval(parts['conf'])
                fit = float(parts['fit'])
                if not 'popConfMat' in data[dsId][mtd].keys():
                   data[dsId][mtd]['popConfMat'] = []
                   data[dsId][mtd]['popfit'] = []
                   data[dsId][mtd]['popTConf2Mat'] = []
                   
                data[dsId][mtd]['popConfMat'].append(conf)
                data[dsId][mtd]['popTConf2Mat'].append(ast.literal_eval(parts['TConf2']))
                data[dsId][mtd]['popfit'].append(fit)

                

            elif line.startswith('#TRPRTNFO;;'):
                        
                parts = GetLineParts(line)
                mtd = parts['For']
                counts = ast.literal_eval(parts['ClsCnt'])
                IDS = [(datasets.index(item[:item.find('@')]),int(item[item.find('@') + 1:])) for item in parts['IDS'][1:-1].split(',')]
                EXTS = [item for item in parts['EXTS'][1:-1].split(',')]
                if not 'trNfoIDS' in data[dsId][mtd].keys():
                   data[dsId][mtd]['trNfoIDS'] = []
                   data[dsId][mtd]['trNfoExts'] = []
                   data[dsId][mtd]['trNfoClassCounts'] = []
                   data[dsId][mtd]['trNfoMCCounts'] = []
                   data[dsId][mtd]['trNfoDstChr'] = []
                data[dsId][mtd]['trNfoIDS'].append(IDS)
                data[dsId][mtd]['trNfoClassCounts'].append(counts)
                data[dsId][mtd]['trNfoExts'].append(EXTS)
                data[dsId][mtd]['trNfoMCCounts'].append(ast.literal_eval(parts['Counts']))
                try:
                    data[dsId][mtd]['trNfoDstChr'].append(ast.literal_eval(parts['DstChr'].replace('NaN','0')))
                except Exception as e:
                    print ('AST ERROR')
                    input()

            elif line.startswith('#TSTPRTNFO;;'):
            
                parts = GetLineParts(line)
                mtd = parts['For']
                counts = ast.literal_eval(parts['ClsCnt'])
                ndx = datasets.index(dataset)
                IDS = [int(item[item.rfind('@') + 1:]) for item in parts['IDS'][1:-1].split(',')]            
                if not 'tsNfoIDS' in data[dsId][mtd].keys():
                   data[dsId][mtd]['tsNfoIDS'] = []
                   data[dsId][mtd]['tsNfoClassCounts'] = []
                   data[dsId][mtd]['tsNfoDstChr'] = []
                data[dsId][mtd]['tsNfoIDS'].append(IDS)
                data[dsId][mtd]['tsNfoClassCounts'].append(counts)            
                data[dsId][mtd]['tsNfoDstChr'].append(ast.literal_eval(parts['DstChr']))

            elif line.startswith('#TSTPRTVALS;;'):
                parts = GetLineParts(line)

                mtd = parts['For']
                conf = ast.literal_eval(parts['conf'])            
                if not 'tstConfMat' in data[dsId][mtd].keys():
                   data[dsId][mtd]['tstConfMat'] = []               
                   
                data[dsId][mtd]['tstConfMat'].append(conf)          
                
            elif line.startswith('Time;;'):
                mtd = line[line.find(';;') + 2:line.find('@')]
                pass
            elif line.startswith('Indexes;;'):
                continue
            elif line.startswith('VC-Raw;;'):
                mtd = line[line.find(';;') + 2:line.find('@')]
                conf = ast.literal_eval(line[line.find(':') + 1:])
                if not 'tstFinalConfMat' in data[dsId][mtd].keys():
                    data[dsId][mtd]['tstFinalConfMat'] = []
                data[dsId][mtd]['tstFinalConfMat'].append(conf)
            elif line.find('Gen-')>=0:
                mtd = line[:line.find('@')]
                
                pass
            elif line.startswith('CV-') or line.startswith('NV-') or line.startswith('NNF-') or line.startswith('NNFMu-'):
                mtd = line[:line.find(':')]
                if not mtd in methods:
                    methods.append(mtd)
                if not mtd in data[dsId].keys():
                    data[dsId][mtd] = {}
                    
                    data[dsId][mtd]['tstFinalConfMat'] = []

                conf = ast.literal_eval(line[line.rfind(';;conf=')+7:])
                data[dsId][mtd]['tstFinalConfMat'].append(conf)

            elif line.startswith('WPM-'):
                mtd = line[:line.find(':')]
                if not mtd in methods:
                    methods.append(mtd)
                if not mtd in data[dsId].keys():
                    data[dsId][mtd] = {}
                    
                    data[dsId][mtd]['tstFinalConfMat'] = []
                if line.rfind('!!!') > 0:
                    
                    conf = data[dsId]['CV-' + mtd[mtd.rfind('-') + 1:]]['tstFinalConfMat'][-1]
                else:
                    
                    conf = ast.literal_eval(line[line.rfind(';;conf=')+7:])
                
                data[dsId][mtd]['tstFinalConfMat'].append(conf)
            elif line.startswith('=================='):
                lineeq = True
                continue
            elif line.startswith('['):
                continue
            else:
                print(line)
                print(lincnt)
                input('Needs processing')

    
        #
        o.close()
    
        if lineeq == False:
            print ('Not Complete for '+file)
        with open(dataPath+str(dsId)+'.json','w') as jfile:
            json.dump(data, jfile)


    else:
        pass
            
with open(dataPath+'Opts.json') as file:
    opts = json.load(file)
    CHRMSize=opts[0]
    NumGens = opts[1]
    popSize= opts[2]
    NumParts= opts[3]
    iters=opts[4]
    sizeTop=opts[5]
    Learner=opts[6]



if not os.path.exists(dataPath+'methods.json'):
    with open(dataPath+'methods.json','w') as jfile:
        json.dump(methods, jfile)
else:
    with open(dataPath+'methods.json') as file:
        methods = json.load(file)

        
print('Data Loaded')

fids = [str(i) for i in range(len(datasets))]


def loadDataset(dsId):
    data = None
    with open(dataPath+str(dsId)+'.json') as file:
        data = json.load(file)
    return data

def getPartValues(dsId,mtd,key):
    
    data = loadDataset(dsId)
    if mtd.find('Gen-')>=0:
        pgvals = {}
        base = 0
        for iter in range(iters):
            pgvals[iter] = {}
            partVals = []
            
            for part in range(NumParts):
                pgvals[iter][part] = {}
                g = data[dsId][mtd]['popGenInfo'][str(iter)][part]
                for gi in range(len(g)):
                    pgvals[iter][part][gi] = data[dsId][mtd][key][base:base+popSize]
                    base+=popSize
    return pgvals


def getPartValuesFromData(data,dsId,mtd,key):
    
    if mtd.find('Gen-')>=0:
        pgvals = {}
        base = 0
        for iter in range(iters):
            pgvals[iter] = {}
            partVals = []
            
            for part in range(NumParts):
                pgvals[iter][part] = {}
                g = data[dsId][mtd]['popGenInfo'][str(iter)][part]
                for gi in range(len(g)):
                    pgvals[iter][part][gi] = data[dsId][mtd][key][base:base+popSize]
                    base+=popSize
    return pgvals
    




measures = sorted(getMeasures(1,2,3,4).keys())
measureTexts = {'GMean1':'GMean','GMean2':'GMean 2','bal':'BALANCE','F':'F-MEASURE','rec':'RECALL','prec':'PRECISION','tnr':'TNR','fnr':'FNR','mcc':'MCC','F0.5':'F0.5','F2':'F2','pf':'PF','fit':'FITNESS'}
methodsGis = [mtd for mtd in methods if mtd.find('Gen-')>=0]
occurrences = lambda s, lst: (i for i,e in enumerate(lst) if e == s)

methodsGisTexts = [r'$'+mtd.replace('Gen-','GIS_{')+'}$' for mtd in methods if mtd.find('Gen-')>=0]



for index, item in enumerate(methodsGisTexts):
    if item.startswith('$GIS'):
        methodsGisTexts[index]='$VNN-'+item[1:]
    elif item.startswith('$VAR.GIS'):
        methodsGisTexts[index] = item.replace('VAR.','VAR.VNN-')
    else:
        continue


for index, item in enumerate(methodsGisTexts):
    if not item.startswith('$VAR.'):
        methodsGisTexts[index]='$FIXED.'+item[1:]
    
weightsData = {}

def WData():
    for fid in fids:
        
        data = loadDataset(fid)

        print (fid)
        
        for mtd in data[fid].keys():
            if not mtd.find('Gen-')>=0:
                continue

            if not mtd in weightsData.keys():
                weightsData[mtd] = {}
                weightsData[mtd]['AVG'] = {}
                weightsData[mtd]['MAX'] = {}
                weightsData[mtd]['MED'] = {}
                weightsData[mtd]['NUM'] = {}


            for iter in range(iters):

                iterIDS = data[fid][mtd]['trNfoIDS'][iter*NumParts:(iter+1)*NumParts]
                
                consfmats = data[fid][mtd]['tstFinalConfMat'][iter*NumParts:(iter+1)*NumParts]
                for partIndex, IDS in enumerate(iterIDS):
                    ms = getMeasures(*consfmats[partIndex])
                    
                    tset = set([tuple(id) for id in IDS])
                    tdic = {t:IDS.count(list(t)) for t in tset}
                    
                    wVals = [v for k,v in tdic.items()]

                    maxW = max(wVals)
                    avgW = np.mean(wVals)
                    numW = len([t for t in wVals if t>1])
                    #medianW = np.median(wVals)
                    
                    if not maxW in weightsData[mtd]['MAX'].keys():
                        weightsData[mtd]['MAX'][maxW] = []
                    if not avgW in weightsData[mtd]['AVG'].keys():
                        weightsData[mtd]['AVG'][avgW] = []
                    #if not medianW in weightsData[mtd]['MED'].keys():
                    #    weightsData[mtd]['MED'][medianW] = []
                    if not numW in weightsData[mtd]['NUM'].keys():
                        weightsData[mtd]['NUM'][numW] = []


                    weightsData[mtd]['MAX'][maxW].append(ms)
                    weightsData[mtd]['AVG'][avgW].append(ms)
                    weightsData[mtd]['NUM'][numW].append(ms)
                    #weightsData[mtd]['MED'][medianW].append(ms)
    

    for mtd in methodsGis:
        for type in ['AVG','MAX','NUM']:
            

            for m in measures:            
                mind = measures.index(m)
                ws = sorted(list(weightsData[mtd][type].keys()))    
                msAvg = [np.mean([dic[m] for dic in weightsData[mtd][type][w]]) for w in ws]
                msStd = [np.std([dic[m] for dic in weightsData[mtd][type][w]]) for w in ws]
                msMed = [np.median([dic[m] for dic in weightsData[mtd][type][w]]) for w in ws]

                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                plt.tight_layout(pad=2)
                for item in ([ax.title, ax.xaxis.label, ax.yaxis.label]+ax.get_xticklabels() + ax.get_yticklabels()):
                    item.set_fontsize(18)

                ax.set_ylim([0, 1])
                mx = max(ws)
                ax.set_xlim([0,mx+2])

                ax.set_ylabel(measureTexts[m])
                

                ax.plot(ws,msAvg, 'g-', linewidth=2)
                
                if not os.path.exists(pltPath+'WData/'):
                    os.makedirs(pltPath+'WData/')        

                    
                pltname = pltPath+'WData/'+'1-Avg--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                pltname = pltPath+'WData/'+'1-Avg--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                fig.savefig(pltname, format='eps', dpi=1000)

                
                for i in range(len(ws)):
                    w = ws[i]
                    ax.plot([w, w], [msAvg[i]-msStd[i],msAvg[i]+msStd[i]], 'r-.')
                    

                if not os.path.exists(pltPath+'WData/'):
                    os.makedirs(pltPath+'WData/')        

                
                pltname = pltPath+'WData/'+'2-Avg+STD--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                pltname = pltPath+'WData/'+'2-Avg+STD--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                fig.savefig(pltname, format='eps', dpi=1000)

                plt.close('all')
                fig = None
                ax = None

                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                plt.tight_layout(pad=2)
                for item in ([ax.title, ax.xaxis.label, ax.yaxis.label]+ax.get_xticklabels() + ax.get_yticklabels()):
                    item.set_fontsize(18)
                ax.set_ylim([0, 1])
                mx = max(ws)
                ax.set_xlim([0,mx+2])

                ax.set_ylabel(measureTexts[m])
                
                
                ax.plot(ws,msMed, 'g-', linewidth=2)
                

                if not os.path.exists(pltPath+'WData/'):
                    os.makedirs(pltPath+'WData/')        
                
                pltname = pltPath+'WData/'+'3-Med--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                pltname = pltPath+'WData/'+'3-Med--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                fig.savefig(pltname, format='eps', dpi=1000)

                plt.close('all')
                fig = None
                ax = None

                print (pltname)                            

                msAvg = None
                msStd = None
                msMed = None

                




o = open('MutCross.txt','w')
countMaxRepeats = {}
allEXTS = {}
allIDS = {}
allIDSvSet = {}


clsTRPerf = {}
clsTSPerf = {}
clsPopPerf = {}
clsPopDelPerf = {}
clsPopTestPerf = {}
clsPopDelTestPerf = {}
clsVSetPerf = {}


xa = {mtd:{m:[] for m in measures} for mtd in methods if mtd.find('Gen-')>=0}
ya = {mtd:{m:[] for m in measures} for mtd in methods if mtd.find('Gen-')>=0}
za = {mtd:{m:[] for m in measures} for mtd in methods if mtd.find('Gen-')>=0}

xat = {mtd:{m:[] for m in measures} for mtd in methods if mtd.find('Gen-')>=0}
yat = {mtd:{m:[] for m in measures} for mtd in methods if mtd.find('Gen-')>=0}
zat = {mtd:{m:[] for m in measures} for mtd in methods if mtd.find('Gen-')>=0}

ucls = set()

def ClassCntFunc():
    for fid in fids:
        data = loadDataset(fid)

        clsTRPerf[fid] ={}
        clsTSPerf[fid] = {}
        clsPopPerf[fid] = {}
        clsPopDelPerf[fid] = {}
        clsPopTestPerf[fid] = {}
        clsPopDelTestPerf[fid] = {}
        clsVSetPerf[fid] = {}


        print(fid)
    
        
    
        for mtd in data[fid].keys():
            if not mtd.find('Gen-')>=0:
                continue

            clsTRPerf[fid][mtd] = []
            clsTSPerf[fid][mtd] = []
            clsPopPerf[fid][mtd] = []
            clsPopDelPerf[fid][mtd] = []
            clsPopTestPerf[fid][mtd] = []
            clsPopDelTestPerf[fid][mtd] = []
            clsVSetPerf[fid][mtd] = []
        


            popConfMats = data[fid][mtd]['popConfMat']
            popTConf2Mats = data[fid][mtd]['popTConf2Mat']
            popClassCounts = data[fid][mtd]['popItNfoClassCounts']
        
            
            ucls.clear()
            for index, clscnt in enumerate(popClassCounts):                                
                cmat = popConfMats[index]
                srep = str(clscnt)+str(cmat)
                if srep in ucls:
                    continue
                ucls.add(srep)
                m = getMeasures(*cmat)
                clsPopPerf[fid][mtd].append([clscnt,[m[mi] for mi in measures]])
                m = None
            


            ucls.clear()
            for index, clscnt in enumerate(popClassCounts):
                cmat = popTConf2Mats[index]
                srep = str(clscnt)+str(cmat)
                if srep in ucls:
                    continue
                ucls.add(srep)
                m = getMeasures(*cmat)
                clsPopTestPerf[fid][mtd].append([clscnt,[m[mi] for mi in measures]])
                m = None
            

            inds = set()
            sampleCount = min(1000, len(clsPopPerf[fid][mtd]))
            while len(inds)<sampleCount:
                inds.add(np.random.randint(0,len(clsPopPerf[fid][mtd])))
            inds = sorted(list(inds))
            inds = [i for i in range(0,len(clsPopPerf[fid][mtd]))]
            for m in measures:                
                x = np.array([clsPopPerf[fid][mtd][i][0][0] for i in inds]) # for i in range(len(clsPopPerf[fid][mtd]))
                y = np.array([clsPopPerf[fid][mtd][i][0][1] for i in inds])
                
                z = np.array([clsPopPerf[fid][mtd][i][1][measures.index(m)] for i in inds])
                xa[mtd][m].extend(x)
                ya[mtd][m].extend(y)
                za[mtd][m].extend(z)

                continue

                fig = plt.figure() #figsize=(20,10)
                ax = fig.gca(projection='3d')
                surf = ax.scatter(x, y, z, cmap=cm.coolwarm, c=z)
                ax.set_zlim(-0.01, 1.01)
                ax.zaxis.set_major_locator(LinearLocator(10))
                ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

                # Add a color bar which maps values to colors.
                fig.colorbar(surf, shrink=0.5, aspect=5)
                ax.set_xlabel('Class 0')
                ax.set_ylabel('Class 1')
                ax.set_zlabel(m)
                if not os.path.exists(pltPath+'ClassCount3D/'):
                    os.makedirs(pltPath+'ClassCount3D/')
                pltname = pltPath+'ClassCount3D/'+'ClassCount3D-'+'PopConfMat--'+datasets[int(fid)]+'--'+'--'+mtd+'--'+m+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                
                plt.close('all')
                fig = None
                ax = None
                surf=None
                x=None
                y=None
                z = None            
                print (pltname)

            ##Delete for now after plotting, to save some ram space.
            clsPopPerf[fid][mtd] = None
            



            inds = set()
            samplecount = min(1000, len(clsPopTestPerf[fid][mtd]))
            while len(inds)<samplecount:
                inds.add(np.random.randint(0,len(clsPopTestPerf[fid][mtd])))
            inds = sorted(list(inds))
            inds = [i for i in range(0,len(clsPopTestPerf[fid][mtd]))]
            for m in measures:                
                x = np.array([clsPopTestPerf[fid][mtd][i][0][0] for i in inds]) # for i in range(len(clsPopPerf[fid][mtd]))
                y = np.array([clsPopTestPerf[fid][mtd][i][0][1] for i in inds])
                
                z = np.array([clsPopTestPerf[fid][mtd][i][1][measures.index(m)] for i in inds])
                xat[mtd][m].extend(x)
                yat[mtd][m].extend(y)
                zat[mtd][m].extend(z)

                continue

                fig = plt.figure() #figsize=(20,10)
                ax = fig.gca(projection='3d')
                surf = ax.scatter(x, y, z, cmap=cm.coolwarm, c=z)
                ax.set_zlim(-0.01, 1.01)
                ax.zaxis.set_major_locator(LinearLocator(10))
                ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

                # Add a color bar which maps values to colors.
                fig.colorbar(surf, shrink=0.5, aspect=5)
                ax.set_xlabel('Class 0')
                ax.set_ylabel('Class 1')
                ax.set_zlabel(m)
                if not os.path.exists(pltPath+'ClassCount3D/'):
                    os.makedirs(pltPath+'ClassCount3D/')
                pltname = pltPath+'ClassCount3D/'+'ClassCount3D-'+'PopTConf2Mat--'+datasets[int(fid)]+'--'+'--'+mtd+'--'+m+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                
                plt.close('all')
                fig = None
                ax = None
                surf=None
                x=None
                y=None
                z = None            
                print (pltname)            
            
            clsPopTestPerf[fid][mtd] = None


    
    names = ['PopTConf2Mat','PopConfMat']
    index = -1
    for xai,yai,zai in [[xat,yat,zat],[xa,ya,za]]:
        index+=1
        for mtd in methods:
            if not mtd.find('Gen-')>=0:
                continue
            for m in ['F']:
                
                x = xai[mtd][m]
                y = yai[mtd][m]                
                z = zai[mtd][m]

                ux = sorted(list(set(x)))
                uy = sorted(list(set(y)))

                #xsortIndex = [i[0] for i in sorted(enumerate(x), key=lambda t:t[1])]
                #ysortIndex = [i[0] for i in sorted(enumerate(x), key=lambda t:t[1])]
                                
                zux = {xi:(np.mean([zi for zindex,zi in enumerate(z) if x[zindex] == xi]),np.std([zi for zindex,zi in enumerate(z) if x[zindex] == xi]),np.median([zi for zindex,zi in enumerate(z) if x[zindex] == xi])) for xi in ux}
                zuy = {yi:(np.mean([zi for zindex,zi in enumerate(z) if y[zindex] == yi]),np.std([zi for zindex,zi in enumerate(z) if y[zindex] == yi]),np.median([zi for zindex,zi in enumerate(z) if y[zindex] == yi])) for yi in uy}
                    

                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                plt.tight_layout(pad=2)
                
                ax.set_ylim([0, 1])
                mx = max(max(ux), max(uy))
                ax.set_xlim([0,mx+2])

                ax.set_ylabel(measureTexts[m])
                
                ax.plot(ux,[zux[xi][0] for xi in ux], 'g-', linewidth=2)
                ax.plot(uy,[zuy[yi][0] for yi in uy], 'r-', linewidth=2)

                ax.legend(['Class 0','Class 1'])

                if not os.path.exists(pltPath+'ClassCountPerClass/'):
                    os.makedirs(pltPath+'ClassCountPerClass/')        

                
                pltname = pltPath+'ClassCountPerClass/'+'1ClassCountPerClass-NoStd--'+names[index]+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                pltname = pltPath+'ClassCountPerClass/'+'1ClassCountPerClass-NoStd--'+names[index]+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                fig.savefig(pltname, format='eps', dpi=1000)

                for xi in ux:
                    ax.plot([xi+0.03, xi+0.03], [zux[xi][0]-zux[xi][1],zux[xi][0]+zux[xi][1]], 'g-.')
                    
                for yi in uy:
                    ax.plot([yi-0.03, yi-0.03], [zuy[yi][0]-zuy[yi][1],zuy[yi][0]+zuy[yi][1]], 'r-.')
                
                #ax.set_title(names[field])        

                if not os.path.exists(pltPath+'ClassCountPerClass/'):
                    os.makedirs(pltPath+'ClassCountPerClass/')        
                
                pltname = pltPath+'ClassCountPerClass/'+'1ClassCountPerClass-'+names[index]+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                pltname = pltPath+'ClassCountPerClass/'+'1ClassCountPerClass-'+names[index]+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                fig.savefig(pltname, format='eps', dpi=1000)

                plt.close('all')
                fig = None
                ax = None

                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                plt.tight_layout(pad=2)
                
                ax.set_ylim([0, 1])
                mx = max(max(ux), max(uy))
                ax.set_xlim([0,mx+2])

                ax.set_ylabel(measureTexts[m])
                
                ax.plot(ux,[zux[xi][2] for xi in ux], 'g-', linewidth=2)
                ax.plot(uy,[zuy[yi][2] for yi in uy], 'r-', linewidth=2)


                ax.legend(['Class 0','Class 1'])

                if not os.path.exists(pltPath+'ClassCountPerClass/'):
                    os.makedirs(pltPath+'ClassCountPerClass/')                                
                            
                pltname = pltPath+'ClassCountPerClass/'+'1ClassCountPerClass-Median--'+names[index]+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                pltname = pltPath+'ClassCountPerClass/'+'1ClassCountPerClass-Median--'+names[index]+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                fig.savefig(pltname, format='eps', dpi=1000)

                plt.close('all')
                fig = None
                ax = None


                x=None
                y=None
                z = None            
                print (pltname)
                ux = None
                uy = None
                zux=None
                zuy = None


    names = ['PopConfMat','PopTConf2Mat']
    index = -1
    for xai,yai,zai in [[xa,ya,za],[xat,yat,zat]]:
        index+=1
        for mtd in methods:
            if not mtd.find('Gen-')>=0:
                continue
            for m in measures:
                fig = plt.figure() #figsize=(20,10)
                ax = fig.gca(projection='3d')
                #plt.tight_layout(pad=1)
                ax.set_xlabel('Class 0')
                ax.set_ylabel('Class 1')
                ax.set_zlabel(m)
        
                
                x = xai[mtd][m]
                y = yai[mtd][m]
                
                z = zai[mtd][m]
                surf = ax.scatter(x, y, z, cmap=cm.coolwarm, c=z)
                ax.set_zlim(-0.01, 1.01)
                ax.zaxis.set_major_locator(LinearLocator(10))
                ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

                # Add a color bar which maps values to colors.
                fig.colorbar(surf, shrink=0.5, aspect=5)
                if not os.path.exists(pltPath+'ClassCount3D/'):
                    os.makedirs(pltPath+'ClassCount3D/')        
                for angle in [i*10 for i in range(36)]:
                    ax.view_init(40, angle)
                    plt.draw()
                    pltname = pltPath+'ClassCount3D/'+'1ClassCount3D-'+names[index]+'--All--'+'--'+mtd+'--'+m+'--'+str(angle)+'.jpg'
                    fig.savefig(pltname, format='jpg', dpi=100)                
                plt.close('all')
                fig = None
                ax = None
                surf=None
                x=None
                y=None
                z = None            
            
                print (pltname)



def IDEXTFunc():
    for fid in fids:
        data = loadDataset(fid)       

        print (fid)
        countMaxRepeats[fid] = {}
        allIDS[fid] = {}
        allEXTS[fid] = {}

    
    
        allIDSvSet[fid] = {}
        for mtd in data[fid].keys():
            if not mtd.find('Gen-')>=0:
                continue

            if mtd.find('Gen')>0:
                pass

            countMaxRepeats[fid][mtd] = []
            allIDS[fid][mtd] = {}
            allEXTS[fid][mtd] = {}
        
            allIDSvSet[fid][mtd] = {}
            for iter in range(iters):



                iterIDS = data[fid][mtd]['trNfoIDS'][iter*NumParts:(iter+1)*NumParts]
                iterEXTS = data[fid][mtd]['trNfoExts'][iter*NumParts:(iter+1)*NumParts]            
                try:
                    iterVSetIDS = data[fid][mtd]['vSetNfoIDS'][iter*NumParts:(iter+1)*NumParts]            
                except Exception as e:
                    pass
                for partIndex, IDS in enumerate(iterIDS):

                    EXTS = iterEXTS[partIndex]
                    vIDS = iterVSetIDS[partIndex]
                    #print (partIndex)

                    for itemIndex,item in enumerate(vIDS):
                        itStr = str(item)
                        if not itStr in allIDSvSet[fid][mtd].keys():
                            allIDSvSet[fid][mtd][itStr] = [0 for _ in range(NumParts)]
                        allIDSvSet[fid][mtd][itStr][partIndex]+=1


                    for itemIndex,item in enumerate(IDS):

                        itemExts = EXTS[itemIndex]
                        itStr = str(item)
                        if not itStr in allIDS[fid][mtd].keys():
                    
                            allIDS[fid][mtd][itStr] = [0 for _ in range(NumParts)]
                            allEXTS[fid][mtd][itStr] = []
                        allIDS[fid][mtd][itStr][partIndex]+=1
                        allEXTS[fid][mtd][itStr].append(itemExts)
                        if itemExts.find('C')>0:
                            print (itemExts)
                        if itemExts.find('M')>0:                        
                            if itemExts.find('M')!=itemExts.rfind('M'):
                                print(itemExts)
                maxRepeats = max([max(t) for t in [v for k,v in allIDS[fid][mtd].items()]])

                countMaxRepeats[fid][mtd].append(maxRepeats)
                #countCrossOvers = [[v for k,v in allEXTS.items()]]
                #print (iter)
            print (mtd, countMaxRepeats[fid][mtd],max(countMaxRepeats[fid][mtd]))


    o.close()



    idCount = {}
    idCountMulti = {}
    idCountDs = {}

    idCountvSet = {}
    idCountMultivSet = {}
    idCountDsvSet = {}



    for fid in fids:
        ifid = int(fid)
    
        for mtd in allIDS[fid].keys():
        
            if not mtd in idCount.keys():
                idCountDs[mtd] = [0 for _ in range(len(fids))]
            
                idCount[mtd] = {}
                idCountMulti[mtd] = {}


                idCountDsvSet[mtd] = [0 for _ in range(len(fids))]
            
                idCountvSet[mtd] = {}
                idCountMultivSet[mtd] = {}


                #if not fid in idCountDs[mtd].keys():
                #    idCountDs[mtd][fid] = 0
            for id in allIDS[fid][mtd].keys():
                idL = ast.literal_eval(id)
                if not id in idCount.keys():
                    idCount[mtd][id] = 0
                    idCountMulti[mtd][id] = 0
                IdData = allIDS[fid][mtd][id]
                idCount[mtd][id]+=len([t for t in IdData if t>0])
                idCountMulti[mtd][id]+=sum(IdData)
                idCountDs[mtd][idL[0]]+=1


            for id in allIDSvSet[fid][mtd].keys():
                idL = ast.literal_eval(id)
                if not id in idCountvSet.keys():
                    idCountvSet[mtd][id] = 0
                    idCountMultivSet[mtd][id] = 0
                IdData = allIDSvSet[fid][mtd][id]
                idCountvSet[mtd][id]+=len([t for t in IdData if t>0])
                idCountMultivSet[mtd][id]+=sum(IdData)
                idCountDsvSet[mtd][idL[0]]+=1



####Mutation Pattern


fields = ["countMutation","countCross","countChangedLabel","countBothCM","countMCnoChange","countMultiMut","countMultiCross"]
fieldsNames = ["Mutation Change Count","Cross Over Change Count","Changed Label Count","Both - Changed","Both - Unchanged","Multi-Mutation Count","Multi-Cross Over Count"]
Colors = ['b','g','r','c','m','y','k']
mcPerf = {}
mcPerfAll = {}
mcuq = set()
mcuqall = set()

def CrossMutPatternFunc2():
    for fid in fids:    
        data = loadDataset(fid)
        print (fid)
    
        for mtd in data[fid].keys():
            if not mtd.find('Gen-')>=0:
                continue
                    
            mccInfo = getPartValuesFromData(data,fid,mtd,'popItNfoMCCounts')            
            testPerfs = getPartValuesFromData(data,fid,mtd,'popTConf2Mat')


            for field in fields:
                
                if not field in mcPerf.keys():
                    mcPerf[field] = {}
                    for mtd2 in methodsGis:
                        if not mtd2 in mcPerf[field].keys():
                            mcPerf[field][mtd2] = {}
                if not field in mcPerfAll.keys():
                    mcPerfAll[field] = {}
                    for mtd2 in methodsGis:
                        if not mtd2 in mcPerfAll[field].keys():
                            mcPerfAll[field][mtd2] = {}

            for iter in range(iters):
                mccInfoIter = mccInfo[iter]

                for part in range(NumParts):
                    for g in range(len(mccInfoIter[part])):
                        mc = mccInfoIter[part][g][0]
                        ms = getMeasures(*testPerfs[iter][part][g][0])
                        if not str(mc)+str(ms) in mcuq:
                            mcuq.add(str(mc)+str(ms))
                            
                            for findex, field in enumerate(fields):
                            
                                if not mc[findex] in mcPerf[field][mtd].keys():
                                    mcPerf[field][mtd][mc[findex]] = []                                                        
                                mcPerf[field][mtd][mc[findex]].append(ms)
                        
                        for pop in range(popSize):
                            mc = mccInfoIter[part][g][pop]
                            ms = getMeasures(*testPerfs[iter][part][g][pop])
                            if not str(mc)+str(ms) in mcuqall:
                                mcuqall.add(str(mc)+str(ms))
                        
                                for findex, field in enumerate(fields):
                                    if not  mc[findex] in mcPerfAll[field][mtd].keys():
                                        mcPerfAll[field][mtd][mc[findex]] = []                                                        
                                    mcPerfAll[field][mtd][mc[findex]].append(ms)                                          

    for mtd in methodsGis:
             
        for  type, dta in [['All', mcPerfAll]]:#,['Top',mcPerf]]:           
            for m in ['F']:
                
                fldData = {}
                for field in fields:
                
                    mind = measures.index(m)
                    ws = sorted(list(dta[field][mtd].keys()))    
                    msAvg = [np.mean([dic[m] for dic in dta[field][mtd][w]]) for w in ws]
                    msStd = [np.std([dic[m] for dic in dta[field][mtd][w]]) for w in ws]
                    msMed = [np.median([dic[m] for dic in dta[field][mtd][w]]) for w in ws]
                    fldData[field] = [ws,msAvg,msStd,msMed]

                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                plt.tight_layout(pad=2)
                for item in ([ax.title, ax.xaxis.label, ax.yaxis.label]+ax.get_xticklabels() + ax.get_yticklabels()):
                    item.set_fontsize(24)
                ax.set_ylim([0, 1])
                mx = max([max(fldData[key][0]) for key in fldData.keys()])
                ax.set_xlim([0,mx+2])

                ax.set_ylabel(measureTexts[m])
                

                
                for fldindex , field in enumerate(fields):
                    ax.plot(fldData[field][0],fldData[field][1],Colors[fldindex]+'-',  linewidth=2)
                
                ax.legend(fieldsNames)

                if not os.path.exists(pltPath+'MCAllData/'):
                    os.makedirs(pltPath+'MCAllData/')        

                    
                pltname = pltPath+'MCAllData/'+'ALLFLDS---'+'1-Avg--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                pltname = pltPath+'MCAllData/'+'ALLFLDS---'+'1-Avg--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                fig.savefig(pltname, format='eps', dpi=1000)

                

                for fldindex, field in enumerate(fields):
                    ws = fldData[field][0]
                    for i in range(len(ws)):
                        w = ws[i]
                        ax.plot([w+0.02*(fldindex+1), w+0.02*(fldindex+1)], [fldData[field][1][i]-fldData[field][2][i],fldData[field][1][i]+fldData[field][2][i]], Colors[fldindex]+'-.')
                    

                if not os.path.exists(pltPath+'MCAllData/'):
                    os.makedirs(pltPath+'MCAllData/')        

                
                pltname = pltPath+'MCAllData/'+'ALLFLDS--2-Avg+Std--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                pltname = pltPath+'MCAllData/'+'ALLFLDS--2-Avg+Std--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                fig.savefig(pltname, format='eps', dpi=1000)

                plt.close('all')
                fig = None
                ax = None

                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                plt.tight_layout(pad=2)
                for item in ([ax.title, ax.xaxis.label, ax.yaxis.label]+ax.get_xticklabels() + ax.get_yticklabels()):
                    item.set_fontsize(18)
                ax.set_ylim([0, 1])
                mx = max([max(fldData[key][0]) for key in fldData.keys()])
                
                ax.set_xlim([0,mx+2])

                ax.set_ylabel(measureTexts[m])
                
                for fldindex , field in enumerate(fields):
                    ax.plot(fldData[field][0],fldData[field][3],Colors[fldindex]+'-',  linewidth=2)
                

                if not os.path.exists(pltPath+'MCAllData/'):
                    os.makedirs(pltPath+'MCAllData/')        
                
                pltname = pltPath+'MCAllData/'+'ALLFLDS--3-Med--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                fig.savefig(pltname, format='jpg', dpi=100)
                pltname = pltPath+'MCAllData/'+'ALLFLDS--3-Med--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                fig.savefig(pltname, format='eps', dpi=1000)

                plt.close('all')
                fig = None
                ax = None
                msAvg = None
                msStd = None
                msMed = None
                fldData = None
                print (pltname)                            
   
        
    for mtd in methodsGis:
        for field in fields:
            for  type, dta in [['All', mcPerfAll],['Top',mcPerf]]:           
                for m in measures:            
                    mind = measures.index(m)
                    ws = sorted(list(dta[field][mtd].keys()))    
                    msAvg = [np.mean([dic[m] for dic in dta[field][mtd][w]]) for w in ws]
                    msStd = [np.std([dic[m] for dic in dta[field][mtd][w]]) for w in ws]
                    msMed = [np.median([dic[m] for dic in dta[field][mtd][w]]) for w in ws]

                    fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                    plt.tight_layout(pad=2)
                
                    ax.set_ylim([0, 1])
                    mx = max(ws)
                    ax.set_xlim([0,mx+2])

                    ax.set_ylabel(measureTexts[m])
                

                    ax.plot(ws,msAvg, 'g-', linewidth=2)
                
                    if not os.path.exists(pltPath+'MCData/'):
                        os.makedirs(pltPath+'MCData/')        

                    
                    pltname = pltPath+'MCData/'+'FLD='+field+'1-Avg--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                    fig.savefig(pltname, format='jpg', dpi=100)
                    pltname = pltPath+'MCData/'+'FLD='+field+'1-Avg--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                    fig.savefig(pltname, format='eps', dpi=1000)

                    
                    for i in range(len(ws)):
                        w = ws[i]
                        ax.plot([w, w], [msAvg[i]-msStd[i],msAvg[i]+msStd[i]], 'r-.')
                    

                    if not os.path.exists(pltPath+'MCData/'):
                        os.makedirs(pltPath+'MCData/')        

                
                    pltname = pltPath+'MCData/'+'FLD='+field+'2-Avg+Std--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                    fig.savefig(pltname, format='jpg', dpi=100)
                    pltname = pltPath+'MCData/'+'FLD='+field+'2-Avg+Std--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                    fig.savefig(pltname, format='eps', dpi=1000)

                    plt.close('all')
                    fig = None
                    ax = None

                    fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                    plt.tight_layout(pad=2)
                
                    ax.set_ylim([0, 1])
                    mx = max(ws)
                    ax.set_xlim([0,mx+2])

                    ax.set_ylabel(measureTexts[m])
                
                    ax.plot(ws,msMed, 'g-', linewidth=2)
                

                    if not os.path.exists(pltPath+'MCData/'):
                        os.makedirs(pltPath+'MCData/')        
                
                    pltname = pltPath+'MCData/'+'FLD='+field+'3-Med--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.jpg'
                    fig.savefig(pltname, format='jpg', dpi=100)
                    pltname = pltPath+'MCData/'+'FLD='+field+'3-Med--ForType='+type+'--All--'+'--'+mtd+'--'+m+'--'+'.eps'
                    fig.savefig(pltname, format='eps', dpi=1000)

                    plt.close('all')
                    fig = None
                    ax = None
                    msAvg = None
                    msStd = None
                    msMed = None
                    print (pltname)                            


    

        

fields = ["countMutation","countCross","countChangedLabel","countBothCM","countMCnoChange","countMultiMut","countMultiCross"]
countsMC = {}
countsMCAvg = {}
countsMCDel = {}
countsMCDelAvg = {}





def CrossMutPatternFunc():
    for fid in fids:    
        data = loadDataset(fid)
        print (fid)    

        countsMC[fid] = {}
        countsMCAvg[fid] = {}
        countsMCDel[fid] = {}
        countsMCDelAvg[fid] = {}

    
        for mtd in data[fid].keys():
            if not mtd.find('Gen-')>=0:
                continue

            countsMC[fid][mtd] = {}
            countsMCAvg[fid][mtd] = {}
            countsMCDel[fid][mtd] = {}
            countsMCDelAvg[fid][mtd] = {}
        
            mccInfo = getPartValuesFromData(data,fid,mtd,'popItNfoMCCounts')
            mccDelInfo = getPartValuesFromData(data,fid,mtd,'popItdelNfoMCCounts')
        
            for field in fields:
                countsMC[fid][mtd][field] = {}
                countsMCAvg[fid][mtd][field] = {}
                countsMCDel[fid][mtd][field] = {}
                countsMCDelAvg[fid][mtd][field] = {}

            for iter in range(iters):
                mccInfoIter = mccInfo[iter]
                mccDelInfoIter = mccDelInfo[iter]
                for field in fields:
                    countsMC[fid][mtd][field][iter] = [[] for _ in range(NumParts)]
                    countsMCAvg[fid][mtd][field][iter] = [[] for _ in range(NumParts)]
                    countsMCDel[fid][mtd][field][iter] = [[] for _ in range(NumParts)]
                    countsMCDelAvg[fid][mtd][field][iter] = [[] for _ in range(NumParts)]

                for part in range(NumParts):
                    for g in range(len(mccInfoIter[part])):
                        for findex, field in enumerate(fields):
                            countsMC[fid][mtd][field][iter][part].append(mccInfoIter[part][g][0][findex])


                        for findex, field in enumerate(fields):
                            v = 0.0
                            for pop in range(popSize):
                                v+=mccInfoIter[part][g][pop][findex]
                            v=v/popSize
                            countsMCAvg[fid][mtd][field][iter][part].append(v)

                    for g in range(len(mccDelInfoIter[part])):
                        for findex, field in enumerate(fields):
                            countsMCDel[fid][mtd][field][iter][part].append(mccDelInfoIter[part][g][0][findex])


                        for findex, field in enumerate(fields):
                            v = 0.0
                            for pop in range(popSize):
                                v+=mccDelInfoIter[part][g][pop][findex]
                            v=v/popSize
                            countsMCDelAvg[fid][mtd][field][iter][part].append(v)
       
        
            types = [['BestOfPop','BestOfDelPop'],['AverageOfPop','AverageOfDelPop']]
            for dindex,dcountsMC in enumerate([[countsMC,countsMCDel],[countsMCAvg, countsMCDelAvg]]):

                for field in fields:

                    fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(30,40))
                    plt.tight_layout(pad=2)
                    plt.rcParams['axes.facecolor'] = 'white'
                    for item in ([ax.title, ax.xaxis.label, ax.yaxis.label]+ax.get_xticklabels() + ax.get_yticklabels()):
                        item.set_fontsize(18)
                    maxX = NumParts*NumGens+1
                    ax.set_xlim([0,maxX])

                    starty = 1
        
                    ax.plot([0,maxX],[starty-0.5, starty-0.5],'k-',linewidth = 1)
                    for iter in range(iters):
                        itermax = 0
                        for part in range(NumParts):
            
                            iterpart = [starty + i for i in dcountsMC[0][fid][mtd][field][iter][part]]
                            if max(iterpart)> itermax:
                                itermax = max(iterpart)
                            ax.plot([NumGens*part+i+1 for i in range(len(iterpart))],iterpart,'g--', linewidth = 2.2)

                            iterpart = [starty + i for i in dcountsMC[1][fid][mtd][field][iter][part]]
                            if max(iterpart)> itermax:
                                itermax = max(iterpart)
                            ax.plot([NumGens*part+i+1 for i in range(len(iterpart))],iterpart,'r-.',linewidth = 2.2)                            

            
                        starty = itermax+1
                        ax.plot([0,maxX],[starty-0.5, starty-0.5],'k-', linewidth = 1)

                    ax.set_ylim([0,starty+1])
                    for part in range(1,NumParts):            
                        ax.plot([NumGens*part+0.5,NumGens*part+0.5],[1, starty+1-0.5],'k-',linewidth = 1)
                    

                    if not os.path.exists(pltPath+'countsMC/'):
                        os.makedirs(pltPath+'countsMC/')
                    fig.savefig(pltPath+'countsMC/'+'countsMC-'+str(types[dindex])+'-AllParts-AllIters-'+datasets[int(fid)]+'--'+'--'+mtd+'--'+field+'.jpg', format='jpg', dpi=100)
                    
                    plt.close('all')
                    fig = None
                    ax = None
                    lstPlots = None
                    print (fid, mtd, field, str(types[dindex]))

        countsMC[fid] = None
        countsMCAvg[fid] = None
        countsMCDel[fid] = None
        countsMCDelAvg[fid] = None


def CorrFunc():
    cf = open('corFile.txt','w')
    cf.write('\t'.join(['File','Part','MTD','Measure 1','Measure 2','PCorr','SPCorr'])+'\n')
    for fid in fids:
        data = loadDataset(fid)
        for mtd in methods:
            if not mtd.find('Gen-')>=0:
                continue

            popConfMat = getPartValuesFromData(data,fid, mtd,'popConfMat')
            popTConf2Mat = getPartValuesFromData(data,fid, mtd,'popTConf2Mat')
            popdelConfMat = getPartValuesFromData(data,fid, mtd,'popdelConfMat')
            popdelTConf2Mat = getPartValuesFromData(data,fid, mtd,'popdelTConf2Mat')        
        

            vals1 = {}
            vals2 = {}
            for m in measures:
                vals1[m] = []
                vals2[m] = []
            
            for iter in range(iters):
                pops1Iter = popConfMat[iter]
                pops2Iter = popTConf2Mat[iter]

                for i in range(NumParts):
                    for gen in range(len(pops1Iter[i])):
                        conf = pops1Iter[i][gen][0]
                        ms = getMeasures(*conf)
                        for k,v in ms.items():
                            vals1[k].append(v)
                    for gen in range(len(pops2Iter[i])):
                        conf = pops2Iter[i][gen][0]
                        ms = getMeasures(*conf)
                        for k,v in ms.items():
                            vals2[k].append(v)

   
    
            for m in measures:
                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                plt.tight_layout(pad=2)

            
    
                ax.set_ylim([0, 1])
                mx = max(len(vals1[m]), len(vals2[m]))
                ax.set_xlim([0,mx])

                ax.set_ylabel(str(iter)+'-'+datasets[int(fid)])
            
                ax.plot([i+1 for i in range(len(vals1[m]))],vals1[m], 'g-.')
                ax.plot([i+1 for i in range(len(vals2[m]))],vals2[m], 'r-.')
                ax.legend(['V','T'])
        
            
                plt.close('all')
                fig = None
                ax = None
                lstPlots = None
                print ('Cor', fid,m, mtd)


            

            vals1 = {}
            vals2 = {}
            for m in measures:
                vals1[m] = [[] for i in range(NumParts)]
                vals2[m] = [[] for i in range(NumParts)]
            #for m in measures:
            for iter in range(iters):
                pops1Iter = popConfMat[iter]
                pops2Iter = popTConf2Mat[iter]

                for i in range(NumParts):
                    for gen in range(len(pops1Iter[i])):
                        conf = pops1Iter[i][gen][0]
                        ms = getMeasures(*conf)
                        for k,v in ms.items():
                            vals1[k][i].append(v)
                    for gen in range(len(pops2Iter[i])):
                        conf = pops2Iter[i][gen][0]
                        ms = getMeasures(*conf)
                        for k,v in ms.items():
                            vals2[k][i].append(v)

   
    
            for m in measures:
                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                plt.tight_layout(pad=2)

            
    
                ax.set_ylim([0, 1])
                mx = 0
                for i in range(NumParts):
                   mx = max(mx,max(len(vals1[m][i]), len(vals2[m][i])))

                ax.set_xlim([0,mx])

                ax.set_ylabel(str(iter)+'-'+datasets[int(fid)])
                axlg = []

                for i in range(NumParts):
    
                    ax.plot([j+1 for j in range(len(vals1[m][i]))],vals1[m][i])
                    ax.plot([j+1 for j in range(len(vals2[m][i]))],vals2[m][i])
                    axlg.append('V-'+str(i+1))
                    axlg.append('T-'+str(i+1))

                #ax.set_title(names[field])
            
                ax.legend(axlg)
        
            
                plt.close('all')
                fig = None
                ax = None
                lstPlots = None
                print ('Cor', fid,m, mtd)


        
            for m1 in measures:
                for m2 in measures:
                    for i in range(NumParts):
                        fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(20,10))
                        plt.tight_layout(pad=2)

            
                        ax.set_ylim([0, 1])
                        mx = 0
                
                        mx = max(len(vals1[m1][i]), len(vals2[m2][i]))

                        ax.set_xlim([0,mx])
                    
                        ticks = [0]
                        for j in range(iters):
                            ticks.append(ticks[-1]+len(popConfMat[j][i]))
                        ax.set_xticks(ticks)
                        ax.set_ylabel('Part'+str(i+1)+'-'+datasets[int(fid)]+'--'+mtd+'--'+m1+'--'+m2)
                        axlg = []
                        for iter in range(iters):
                            ax.plot([j+1 for j in range(ticks[iter], ticks[iter+1])],vals1[m1][i][ticks[iter]:ticks[iter+1]],'r-')
                            ax.plot([j+1 for j in range(ticks[iter], ticks[iter+1])],vals2[m2][i][ticks[iter]:ticks[iter+1]],'g-')
                        cf.write('\t'.join([datasets[int(fid)],str(i+1),mtd,m1,m2,str(pearsonr(vals1[m1][i],vals2[m2][i])),str(spearmanr(vals1[m1][i],vals2[m2][i]))])+'\n')
                        axlg.append('V-'+str(i+1)+'   For '+m1)
                        axlg.append('T-'+str(i+1)+'   For '+m2)

                        #ax.set_title(names[field])
            
                        ax.legend(axlg)
        
                      
                        if not os.path.exists(pltPath+'Cor-Rel/'):
                            os.makedirs(pltPath+'Cor-Rel/')
                    

                        fig.savefig(pltPath+'Cor-Rel/'+'Cor-Only FirstGen-Part-'+str(i+1)+'--'+datasets[int(fid)]+'--'+m1+'--'+m2+'--'+mtd+'.jpg', format='jpg', dpi=100)
                      
                        plt.close('all')
                        fig = None
                        ax = None
                        lstPlots = None
                        print ('Cor', fid,m1,m2, mtd)



import pandas as pd
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm
from statsmodels.graphics.factorplots import interaction_plot
from scipy import stats


def eta_squared(aov):
    aov['eta_sq'] = 'NaN'
    aov['eta_sq'] = aov[:-1]['sum_sq']/sum(aov['sum_sq'])
    return aov
 
def omega_squared(aov):
    mse = aov['sum_sq'][-1]/aov['df'][-1]
    aov['omega_sq'] = 'NaN'
    aov['omega_sq'] = (aov[:-1]['sum_sq']-(aov[:-1]['df']*mse))/(sum(aov['sum_sq'])+mse)
    return aov

def PerMeasurePerDataFuncOnlyGisAnova():
    vals = {}

    
    
    for m in measures:
        vals[m] = [[] for _ in range(len(methodsGis))]
        
    
    for fid in fids:            
        data = loadDataset(fid)
        print (fid)
        for index,mtd in enumerate(methodsGis):        
            if mtd.find('Gen-')<0:
                continue
            confMats = data[fid][mtd]['tstFinalConfMat']
            for conf in confMats:
                ms=getMeasures(*conf)
                for k,v in ms.items():
                    if math.isnan(v):
                        v = 0
                    if str(v).lower() == 'nan':
                        v = 0
                    vals[k][index].append(v)

    df = pd.DataFrame(columns=measures+['vType','trType','FTR','LRN','FITFUNC'])
    
    rownum = 0
    for index,mtd in enumerate(methodsGis):        
        if mtd.find('Gen-')<0:      
            continue

        mtdTx = methodsGisTexts[index]
        tt = mtdTx[1:mtdTx.find('.')]
        vt = mtdTx[mtdTx.find('.')+1:mtdTx.find('-')]
        ftr = mtdTx[mtdTx.find('{')+1:mtdTx.find('}')]
        count  = len(vals[measures[0]][index])
        for i in range(count):
            df.loc[rownum] = [vals[m][index][i] for m in measures] + [vt,tt,ftr, usedLrn,''.join(fitFunc)]
            
            rownum+=1
    df2 = df.copy()


    for m in measures:
        print (m)
        dtam = list(df2[m])
        mx = max (dtam)
        dtam = [math.sqrt(mx - val) for val in dtam]
        try:

            df2[m] = dtam 
        except Exception as e:
            print ('BC failed for ',m)

    plt.figure(figsize=(20,20))
                
    anovfor = usedLrn+'-'+''.join(fitFunc) + '--'
    anovFile = open(anovfor+'AnovaOut-v.txt','w')
    for m in measures:
        if m.find('.')>=0:
            continue
        mod = ols(m+' ~ C(vType)',
                data=df).fit()
           
        mod2 = ols(m+' ~ C(vType)',
                data=df2).fit()
        plt.cla()
        plt.clf()
        
        
        resid = list(mod.resid)
        stats.probplot(resid, dist="norm", plot=plt)
        plt.savefig(pltPath+'QQ-Before-'+anovfor+'-- '+m+'--VType.jpg', dpi = 300)
        
        plt.cla()
        plt.clf()
       
        fig = None
        #plt.close('all')
        
        
        #fig = plt.figure(figsize=(20,20))
        plt.cla()
        plt.clf()
        print ('Orig:', stats.normaltest(list(resid)))     
        resid = list(mod2.resid)
        stats.probplot(resid, dist="norm", plot=plt)
        plt.savefig(pltPath+'QQ-After-'+anovfor+'-- '+m+'--VType.jpg', dpi = 300)
        #plt.show()
        plt.cla()
        plt.clf()
        
        fig = None
        #plt.close('all')
        plt.clf()
        plt.cla()
        print ('Box-Cox:',stats.normaltest(list(resid)))     
        
        aov_table = sm.stats.anova_lm(mod, typ=2)
        
        eta_squared(aov_table)
        omega_squared(aov_table)
        anovFile.write('-----For Meaure: '+measureTexts[m]+'-------\n\n')
        anovFile.write (str(aov_table))

        anovFile.write('\n\n-------------------------------------------\n\n\n\n')
        print ('Anova For', m)
    anovFile.close()

    anovFile = open(anovfor+'AnovaOut-tr.txt','w')
    for m in measures:
        
        if m.find('.')>=0:
            continue
        mod = ols(m+' ~ C(trType)',
                data=df).fit()
        
        mod2 = ols(m+' ~ C(trType)',
                data=df2).fit()
 
        plt.cla()
        plt.clf()
        #fig = plt.figure(figsize=(20,20))
        plt.cla()
        plt.clf()
        resid = list(mod.resid)
        stats.probplot(resid, dist="norm", plot=plt)
        plt.savefig(pltPath+'QQ-Before-'+anovfor+'-- '+m+'--trType.jpg', dpi = 300)
        plt.cla()
        plt.clf()
        #plt.close('all')
        
        
        #fig = plt.figure(figsize=(20,20))
        plt.cla()
        plt.clf()
        print ('Orig:', stats.normaltest(list(resid)))     
        resid = list(mod2.resid)
        stats.probplot(resid, dist="norm", plot=plt)
        plt.savefig(pltPath+'QQ-After-'+anovfor+'-- '+m+'--trType.jpg', dpi = 300)
        plt.cla()
        plt.clf()
        
        fig = None
        #plt.close('all')
       
        print ('Box-Cox:',stats.normaltest(list(resid)))     
              
        aov_table = sm.stats.anova_lm(mod, typ=2)
 
        eta_squared(aov_table)
        omega_squared(aov_table)
        anovFile.write('-----For Meaure: '+measureTexts[m]+'-------\n\n')
        anovFile.write (str(aov_table))

        anovFile.write('\n\n-------------------------------------------\n\n\n\n')
        print ('Anova For', m)
    anovFile.close()

    anovFile = open(anovfor+'AnovaOut-FTR.txt','w')
    for m in measures:
        if m.find('.')>=0:
            continue
        mod = ols(m+' ~ C(FTR)',
                data=df).fit()
        
        mod2 = ols(m+' ~ C(FTR)',
                data=df2).fit()
        plt.cla()
        plt.clf()
        #fig = plt.figure(figsize=(20,20))
        plt.cla()
        plt.clf()
        resid = list(mod.resid)
        stats.probplot(resid, dist="norm", plot=plt)
        plt.savefig(pltPath+'QQ-Before-'+anovfor+'-- '+m+'--FTR.jpg', dpi = 300)
        plt.cla()
        plt.clf()
        
        fig = None
        #plt.close('all')
        #fig = plt.figure(figsize=(20,20))
        plt.cla()
        plt.clf()
        print ('Orig:', stats.normaltest(list(resid)))     
        resid = list(mod2.resid)
        stats.probplot(resid, dist="norm", plot=plt)
        plt.savefig(pltPath+'QQ-After-'+anovfor+'-- '+m+'--FTR.jpg', dpi = 300)
        plt.cla()
        plt.clf()
        #plt.close('all')
        fig = None
        print ('Box-Cox:',stats.normaltest(list(resid)))     
                
        aov_table = sm.stats.anova_lm(mod, typ=2)
 
        eta_squared(aov_table)
        omega_squared(aov_table)
        anovFile.write('-----For Meaure: '+measureTexts[m]+'-------\n\n')
        anovFile.write (str(aov_table))

        anovFile.write('\n\n-------------------------------------------\n\n\n\n')
        print ('Anova For', m)
    anovFile.close()

    plt.close('all')
    
    df.to_csv(anovfor+'data_df.csv')
    print (rownum)
    input('Saved')

    for m in measures:
        fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(2*1*len(methodsGis),4))
        plt.tight_layout(pad=2)

        if m=='rec':
            pass
        plt.tick_params(
            axis='x',          # changes apply to the x-axis
            which='both',      # both major and minor ticks are affected
            bottom='off',      # ticks along the bottom edge are off
            top='off',         # ticks along the top edge are off
            labelbottom='off') # labels along the bottom edge are off
    
    
        ax.set_ylim([0, 1])
        lstPlots = vals[m]

        medians = [np.median(l) for l in lstPlots]
        indexes = [i[0] for i in sorted(enumerate(medians), key=lambda x:x[1])]

        lstPlots = [lstPlots[ind] for ind in indexes]

        lbls2 = [methodsGisTexts[ind] for ind in indexes]

        
        ax.set_xlim([0,len(lbls2)])

        yl = m
        if m in measureTexts.keys():
            yl = measureTexts[m]

        ax.set_ylabel(yl,fontsize=18)
        #ax.text(-0.52, 0.6+len(yl)/70, , rotation=90, fontsize=16)
        pos = 0.025
        for lbl in lbls2:
            ax.text(pos-0.52, 0.6+len(lbl)/70, lbl, rotation=90, fontsize=16)
            pos+=1
       
        seaborn.violinplot(ax = ax, data=lstPlots,scale="width", inner='box',linewidth=2, color='#e7e422')
    
        #ax.set_title(names[field])
    
        
        #fig.savefig('PLT/TST_FINAL_PER_MEASURE-'+mtd+'--'+m+'.eps', format='jpg', dpi=1000)


        if not os.path.exists(pltPath+'TST_FINAL_ONLYGIS/'):
            os.makedirs(pltPath+'TST_FINAL_ONLYGIS/')
        fig.savefig(pltPath+'TST_FINAL_ONLYGIS/'+'TST_FINAL_ALL_PER_MEASURE_METHODS-'+'--'+m+'.jpg', format='jpg', dpi=100)
        fig.savefig(pltPath+'TST_FINAL_ONLYGIS/'+'TST_FINAL_ALL_PER_MEASURE_METHODS-'+'--'+m+'.eps', format='eps', dpi=1000)
        #except Exception as ee:
        #    print ("VPLOT Error",ee,[len(t) for t in llst2],[min(t) for t in llst2], [max(t) for t in llst2])

        plt.close('all')
        fig = None
        ax = None
        lstPlots = None
        print ('TST FINAL ONLY GIS', m)



def PerMeasurePerDataFuncOnlyGis():
    vals = {}
    for m in measures:
        vals[m] = [[] for _ in range(len(methodsGis))]
            
    for fid in fids:            
        data = loadDataset(fid)
        print (fid)
        for index,mtd in enumerate(methodsGis):        
            if mtd.find('Gen-')<0:      
                continue
            confMats = data[fid][mtd]['tstFinalConfMat']
            for conf in confMats:
                ms=getMeasures(*conf)
                for k,v in ms.items():
                    vals[k][index].append(v)


    for m in measures:
        fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(2*1*len(methodsGis),4))
        plt.tight_layout(pad=2)

        if m=='rec':
            pass
        plt.tick_params(
            axis='x',          # changes apply to the x-axis
            which='both',      # both major and minor ticks are affected
            bottom='off',      # ticks along the bottom edge are off
            top='off',         # ticks along the top edge are off
            labelbottom='off') # labels along the bottom edge are off
    
    
        ax.set_ylim([0, 1])
        lstPlots = vals[m]

        medians = [np.median(l) for l in lstPlots]
        
        indexes = [i[0] for i in sorted(enumerate(medians), key=lambda x:x[1])]

        lstPlots = [lstPlots[ind] for ind in indexes]

        lbls2 = [methodsGisTexts[ind] for ind in indexes]
        
        stpr = m +"  --   "+ ", ".join([lbl+":"+ "%0.3f" % sorted(medians)[tind] for tind,lbl in enumerate(lbls2)])
        
        print (m, lbls2, sorted(medians))
        print (stpr)
        
        ax.set_xlim([0,len(lbls2)])

        yl = m
        if m in measureTexts.keys():
            yl = measureTexts[m]

        ax.set_ylabel(yl,fontsize=18)
        #ax.text(-0.52, 0.6+len(yl)/70, , rotation=90, fontsize=16)
        pos = 0.025
        for lbl in lbls2:
            ax.text(pos-0.52, 0.6+len(lbl)/70, lbl, rotation=90, fontsize=16)
            pos+=1
       
        seaborn.violinplot(ax = ax, data=lstPlots,scale="width", inner='box',linewidth=2, color='#e7e422')
    
        #ax.set_title(names[field])
    
        
        #fig.savefig('PLT/TST_FINAL_PER_MEASURE-'+mtd+'--'+m+'.eps', format='jpg', dpi=1000)


        if not os.path.exists(pltPath+'TST_FINAL_ONLYGIS/'):
            os.makedirs(pltPath+'TST_FINAL_ONLYGIS/')
        fig.savefig(pltPath+'TST_FINAL_ONLYGIS/'+'TST_FINAL_ALL_PER_MEASURE_METHODS-'+'--'+m+'.jpg', format='jpg', dpi=100)
        fig.savefig(pltPath+'TST_FINAL_ONLYGIS/'+'TST_FINAL_ALL_PER_MEASURE_METHODS-'+'--'+m+'.eps', format='eps', dpi=1000)
        #except Exception as ee:
        #    print ("VPLOT Error",ee,[len(t) for t in llst2],[min(t) for t in llst2], [max(t) for t in llst2])

        plt.close('all')
        fig = None
        ax = None
        lstPlots = None
        print ('TST FINAL ONLY GIS', m)


def PerMeasurePerDataFunc():
    vals = {}
    for m in measures:
        vals[m] = [[] for _ in range(len(methods))]
    #for m in measures:

    for fid in fids:            
        data = loadDataset(fid)
        print (fid)
        for index,mtd in enumerate(methods):        
        
            confMats = data[fid][mtd]['tstFinalConfMat']
            for conf in confMats:
                ms=getMeasures(*conf)
                for k,v in ms.items():
                    vals[k][index].append(v)


    for m in measures:
        fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(2*1*len(methods),4))
        plt.tight_layout(pad=2)

        plt.tick_params(
            axis='x',          # changes apply to the x-axis
            which='both',      # both major and minor ticks are affected
            bottom='off',      # ticks along the bottom edge are off
            top='off',         # ticks along the top edge are off
            labelbottom='off') # labels along the bottom edge are off
    
    
        ax.set_ylim([0, 1])
        lstPlots = vals[m]

        medians = [np.median(l) for l in lstPlots]
        indexes = [i[0] for i in sorted(enumerate(medians), key=lambda x:x[1])]

        lstPlots = [lstPlots[ind] for ind in indexes]

        lbls2 = [methods[ind] for ind in indexes]
    
        ax.set_xlim([0,len(lbls2)])

        ax.set_ylabel('All'+'-'+measureTexts[m])
        
        pos = 0.025
        for lbl in lbls2:
            ax.text(pos-0.5, 0.3+len(lbl)/70, lbl, rotation=90) 
            pos+=1


    
    
        seaborn.violinplot(ax = ax, data=lstPlots,scale="width", inner='box',linewidth=8, color='#e7e422')       
    
        #ax.set_title(names[field])
    
        
        #fig.savefig('PLT/TST_FINAL_PER_MEASURE-'+mtd+'--'+m+'.eps', format='jpg', dpi=1000)


        if not os.path.exists(pltPath+'TST_FINAL/'):
            os.makedirs(pltPath+'TST_FINAL/')
        fig.savefig(pltPath+'TST_FINAL/'+'TST_FINAL_ALL_PER_MEASURE_METHODS-'+'--'+m+'.jpg', format='jpg', dpi=100)
        #except Exception as ee:
        #    print ("VPLOT Error",ee,[len(t) for t in llst2],[min(t) for t in llst2], [max(t) for t in llst2])

        plt.close('all')
        fig = None
        ax = None
        lstPlots = None
        print ('TST FINAL', m, mtd)



    for mtd in methods:
        vals = {}
        for m in measures:
            vals[m] = []
    
            for fid in fids:
                vals[m].append([]) 
        for fid in fids:
            ind = int(fid)
            data = loadDataset(fid)
            confMats = data[fid][mtd]['tstFinalConfMat']

            for conf in confMats:
                ms=getMeasures(*conf)
                for k,v in ms.items():
                    vals[k][ind].append(v)


        for m in measures:
            fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(2*0.5*len(fids),4))
            plt.tight_layout(pad=2)

            plt.tick_params(
                axis='x',          # changes apply to the x-axis
                which='both',      # both major and minor ticks are affected
                bottom='off',      # ticks along the bottom edge are off
                top='off',         # ticks along the top edge are off
                labelbottom='off') # labels along the bottom edge are off
    
    
            ax.set_ylim([0, 1])
            lstPlots = vals[m]
            lbls2 = datasets
        
            ax.set_xlim([0,len(lbls2)])

            ax.set_ylabel(mtd+'-'+measureTexts[m])
        
            pos = 0.025
            for lbl in lbls2:
                ax.text(pos-0.5, 0.3+len(lbl)/70, lbl, rotation=90) 
                pos+=1


    
    
            seaborn.violinplot(ax = ax, data=lstPlots,scale="width", inner='box',linewidth=8, color='#e7e422')       
    
            #ax.set_title(names[field])
    
            if not os.path.exists(pltPath+'TST_FINAL/'):
                os.makedirs(pltPath+'TST_FINAL/')
        
            #fig.savefig('PLT/TST_FINAL_PER_MEASURE-'+mtd+'--'+m+'.eps', format='jpg', dpi=1000)
            fig.savefig(pltPath+'TST_FINAL/'+'TST_FINAL_PER_MEASURE-'+mtd+'--'+m+'.jpg', format='jpg', dpi=100)
            #except Exception as ee:
            #    print ("VPLOT Error",ee,[len(t) for t in llst2],[min(t) for t in llst2], [max(t) for t in llst2])

            plt.close('all')
            fig = None
            ax = None
            lstPlots = None
            print ('TST FINAL', m, mtd)
                

    for fid in fids:
        for mtd in methods:
            if not mtd.find('Gen-')>=0:
                continue

            popConfMat = getPartValues(fid, mtd,'popConfMat')
            popTConf2Mat = getPartValues(fid, mtd,'popTConf2Mat')
            popdelConfMat = getPartValues(fid, mtd,'popdelConfMat')
            popdelTConf2Mat = getPartValues(fid, mtd,'popdelTConf2Mat')        
               


            vals1 = {}
            vals2 = {}
            for m in measures:
                vals1[m] = [[] for iter in range(iters)]
                vals2[m] = [[] for iter in range(iters)]
            #for m in measures:
            for iter in range(iters):
                pops1Iter = popConfMat[iter]
                pops2Iter = popTConf2Mat[iter]

                for i in range(NumParts):
                    for gen in range(len(pops1Iter[i])):
                        for j in range(len(pops1Iter[i][gen])):
                            conf = pops1Iter[i][gen][j]
                            ms = getMeasures(*conf)
                            for k,v in ms.items():
                                vals1[k][iter].append(v)
                    for gen in range(len(pops2Iter[i])):
                        for j in range(len(pops2Iter[i][gen])):
                            conf = pops2Iter[i][gen][j]
                            ms = getMeasures(*conf)
                            for k,v in ms.items():
                                vals2[k][iter].append(v)


    

    
            for iter in range(iters):
                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(2*2*len(measures),4))
                plt.tight_layout(pad=2)

                plt.tick_params(
                    axis='x',          # changes apply to the x-axis
                    which='both',      # both major and minor ticks are affected
                    bottom='off',      # ticks along the bottom edge are off
                    top='off',         # ticks along the top edge are off
                    labelbottom='off') # labels along the bottom edge are off
    
    
                ax.set_ylim([0, 1])
                lstPlots = []
                lbls2 = []
                for m in measures:
                    lstPlots.append(vals1[m][iter])
                    lstPlots.append(vals2[m][iter])
                    lbls2.append(m+'-V')
                    lbls2.append(m+'-T')

                ax.set_xlim([0,len(lbls2)])

                ax.set_ylabel(str(iter)+'-'+datasets[int(fid)])
                

                pos = 0.025
                for lbl in lbls2:
                    ax.text(pos-0.5, 0.3+len(lbl)/70, lbl, rotation=90) 
                    pos+=1


    
    
                seaborn.violinplot(ax = ax, data=lstPlots,scale="width", inner='box',linewidth=8, color='#e7e422')       
    
                #ax.set_title(names[field])
    
                if not os.path.exists(pltPath+'VT-vs-TV/'):
                    os.makedirs(pltPath+'VT-vs-TV/')
            
                #fig.savefig('PLT/VvsT-All-'+fid+'--'+str(iter)+'--'+mtd+'.eps', format='eps', dpi=1000)
                fig.savefig(pltPath+'VT-vs-TV/'+'VvsT-All-'+datasets[int(fid)]+'--'+str(iter)+'--'+mtd+'.jpg', format='jpg', dpi=100)
                #except Exception as ee:
                #    print ("VPLOT Error",ee,[len(t) for t in llst2],[min(t) for t in llst2], [max(t) for t in llst2])

                plt.close('all')
                fig = None
                ax = None
                lstPlots = None
                print ('PLT VvsT', fid,iter, mtd)





                
            vals1 = {}
            vals2 = {}
            for m in measures:
                vals1[m] = [[] for iter in range(iters)]
                vals2[m] = [[] for iter in range(iters)]
            #for m in measures:
            for iter in range(iters):
                pops1Iter = popConfMat[iter]
                pops2Iter = popdelConfMat[iter]

                for i in range(NumParts):
                    for gen in range(len(pops1Iter[i])-1):
                        for j in range(len(pops1Iter[i][gen+1])):
                            conf = pops1Iter[i][gen+1][j]
                            ms = getMeasures(*conf)
                            for k,v in ms.items():
                                vals1[k][iter].append(v)
                    for gen in range(len(pops2Iter[i])-1):
                        for j in range(len(pops2Iter[i][gen])):
                            conf = pops2Iter[i][gen][j]
                            ms = getMeasures(*conf)
                            for k,v in ms.items():
                                vals2[k][iter].append(v)


    



    
            for iter in range(iters):
                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(2*2*len(measures),4))
                plt.tight_layout(pad=2)

                plt.tick_params(
                    axis='x',          # changes apply to the x-axis
                    which='both',      # both major and minor ticks are affected
                    bottom='off',      # ticks along the bottom edge are off
                    top='off',         # ticks along the top edge are off
                    labelbottom='off') # labels along the bottom edge are off
    
    
                ax.set_ylim([0, 1])
                lstPlots = []
                lbls2 = []
                for m in measures:
                    lstPlots.append(vals1[m][iter])
                    lstPlots.append(vals2[m][iter])
                    lbls2.append(m+'-V')
                    lbls2.append(m+'-VDel')

                ax.set_xlim([0,len(lbls2)])

                ax.set_ylabel(str(iter)+'-'+datasets[int(fid)])
                

                pos = 0.025
                for lbl in lbls2:
                    ax.text(pos-0.5, 0.3+len(lbl)/70, lbl, rotation=90) 
                    pos+=1


    
    
                seaborn.violinplot(ax = ax, data=lstPlots,scale="width", inner='box',linewidth=8, color='#e7e422')       
    
                #ax.set_title(names[field])
                if not os.path.exists(pltPath+'VT-vs-TV/'):
                    os.makedirs(pltPath+'VT-vs-TV/')
            
        
                #fig.savefig('PLT/VvsVdel-All-'+fid+'--'+str(iter)+'--'+mtd+'.eps', format='eps', dpi=1000)
                fig.savefig(pltPath+'VT-vs-TV/'+'VvsVdel-All-'+datasets[int(fid)]+'--'+str(iter)+'--'+mtd+'.jpg', format='jpg', dpi=100)
                #except Exception as ee:
                #    print ("VPLOT Error",ee,[len(t) for t in llst2],[min(t) for t in llst2], [max(t) for t in llst2])

                plt.close('all')
                fig = None
                ax = None
                lstPlots = None
                print ('PLT VvsTdel', fid,iter, mtd)

        
            
            
            vals1 = {}
            vals2 = {}
            for m in measures:
                vals1[m] = [[] for iter in range(iters)]
                vals2[m] = [[] for iter in range(iters)]
            #for m in measures:
            for iter in range(iters):
                pops1Iter = popTConf2Mat[iter]
                pops2Iter = popdelTConf2Mat[iter]

                for i in range(NumParts):
                    for gen in range(len(pops1Iter[i])-1):
                        for j in range(len(pops1Iter[i][gen+1])):
                            conf = pops1Iter[i][gen+1][j]
                            ms = getMeasures(*conf)
                            for k,v in ms.items():
                                vals1[k][iter].append(v)
                    for gen in range(len(pops2Iter[i])-1):
                        for j in range(len(pops2Iter[i][gen])):
                            conf = pops2Iter[i][gen][j]
                            ms = getMeasures(*conf)
                            for k,v in ms.items():
                                vals2[k][iter].append(v)


    



    
            for iter in range(iters):
                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(2*2*len(measures),4))
                plt.tight_layout(pad=2)

                plt.tick_params(
                    axis='x',          # changes apply to the x-axis
                    which='both',      # both major and minor ticks are affected
                    bottom='off',      # ticks along the bottom edge are off
                    top='off',         # ticks along the top edge are off
                    labelbottom='off') # labels along the bottom edge are off
    
    
                ax.set_ylim([0, 1])
                lstPlots = []
                lbls2 = []
                for m in measures:
                    lstPlots.append(vals1[m][iter])
                    lstPlots.append(vals2[m][iter])
                    lbls2.append(m+'-T')
                    lbls2.append(m+'-TDel')

                ax.set_xlim([0,len(lbls2)])

                ax.set_ylabel(str(iter)+'-'+datasets[int(fid)])
                

                pos = 0.025
                for lbl in lbls2:
                    ax.text(pos-0.5, 0.3+len(lbl)/70, lbl, rotation=90) 
                    pos+=1


    
    
                seaborn.violinplot(ax = ax, data=lstPlots,scale="width", inner='box',linewidth=8, color='#e7e422')       
    
                #ax.set_title(names[field])
                if not os.path.exists(pltPath+'VT-vs-TV/'):
                    os.makedirs(pltPath+'VT-vs-TV/')
            
        
                #fig.savefig('PLT/TvsTdel-All-'+fid+'--'+str(iter)+'--'+mtd+'.eps', format='eps', dpi=1000)
                fig.savefig(pltPath+'VT-vs-TV/'+'TvsTdel-All-'+datasets[int(fid)]+'--'+str(iter)+'--'+mtd+'.jpg', format='jpg', dpi=100)
                #except Exception as ee:
                #    print ("VPLOT Error",ee,[len(t) for t in llst2],[min(t) for t in llst2], [max(t) for t in llst2])

                plt.close('all')
                fig = None
                ax = None
                lstPlots = None
                print ('PLT TvsTdel', fid,iter, mtd)


            vals1 = {}
            vals2 = {}
            for m in measures:
                vals1[m] = [[] for iter in range(iters)]
                vals2[m] = [[] for iter in range(iters)]
            #for m in measures:
            for iter in range(iters):
                pops1Iter = popdelConfMat[iter]
                pops2Iter = popdelTConf2Mat[iter]

                for i in range(NumParts):
                    for gen in range(len(pops1Iter[i])-1):
                        for j in range(len(pops1Iter[i][gen+1])):
                            conf = pops1Iter[i][gen+1][j]
                            ms = getMeasures(*conf)
                            for k,v in ms.items():
                                vals1[k][iter].append(v)
                    for gen in range(len(pops2Iter[i])-1):
                        for j in range(len(pops2Iter[i][gen])):
                            conf = pops2Iter[i][gen][j]
                            ms = getMeasures(*conf)
                            for k,v in ms.items():
                                vals2[k][iter].append(v)


    



    
            for iter in range(iters):
                fig,ax = plt.subplots(ncols = 1,nrows = 1,figsize=(2*2*len(measures),4))
                plt.tight_layout(pad=2)

                plt.tick_params(
                    axis='x',          # changes apply to the x-axis
                    which='both',      # both major and minor ticks are affected
                    bottom='off',      # ticks along the bottom edge are off
                    top='off',         # ticks along the top edge are off
                    labelbottom='off') # labels along the bottom edge are off
    
    
                ax.set_ylim([0, 1])
                lstPlots = []
                lbls2 = []
                for m in measures:
                    lstPlots.append(vals1[m][iter])
                    lstPlots.append(vals2[m][iter])
                    lbls2.append(m+'-VDel')
                    lbls2.append(m+'-TDel')

                ax.set_xlim([0,len(lbls2)])

                ax.set_ylabel(str(iter)+'-'+datasets[int(fid)])
                

                pos = 0.025
                for lbl in lbls2:
                    ax.text(pos-0.5, 0.3+len(lbl)/70, lbl, rotation=90) 
                    pos+=1


    
    
                seaborn.violinplot(ax = ax, data=lstPlots,scale="width", inner='box',linewidth=8, color='#e7e422')       
    
                #ax.set_title(names[field])
                if not os.path.exists(pltPath+'VT-vs-TV/'):
                    os.makedirs(pltPath+'VT-vs-TV/')
            
        
                #fig.savefig('PLT/VdelvsTdel-All-'+fid+'--'+str(iter)+'--'+mtd+'.eps', format='eps', dpi=1000)
                fig.savefig(pltPath+'VT-vs-TV/'+'VdelvsTdel-All-'+datasets[int(fid)]+'--'+str(iter)+'--'+mtd+'.jpg', format='jpg', dpi=100)
                #except Exception as ee:
                #    print ("VPLOT Error",ee,[len(t) for t in llst2],[min(t) for t in llst2], [max(t) for t in llst2])

                plt.close('all')
                fig = None
                ax = None
                lstPlots = None
                print ('PLT VdelvsTdel', fid,iter, mtd)



PerMeasurePerDataFuncOnlyGisAnova()

PerMeasurePerDataFuncOnlyGis()

ClassCntFunc()
CrossMutPatternFunc2()

PerMeasurePerDataFuncOnlyGis()
WData()


IDEXTFunc()
CrossMutPatternFunc()
CorrFunc()
PerMeasurePerDataFunc()